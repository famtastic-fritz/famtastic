/* Research Center — evidence-first */

function ScreenResearch() {
  const [depth, setDepth] = React.useState("Standard");

  return (
    <div className="fade-up">
      <SectionHeader
        eyebrow="Research Center · 12 briefs · 84 sources"
        title="Evidence before we build."
        sub="Pull patterns from real sites, score the gap, and feed findings into Sites, Media, and Components."
        right={
          <>
            <div className="seg" title="Depth">
              {["Fast","Standard","Deep","Expert"].map(d => <button key={d} className={depth === d ? "on" : ""} onClick={() => setDepth(d)}>{d}</button>)}
            </div>
            <Btn icon="search" kind="primary">New brief</Btn>
          </>
        }
      />

      {/* Active brief */}
      <Card hi style={{ marginBottom: 14, position: "relative" }}>
        <div className="row between">
          <div className="row gap-3">
            <div style={{ width: 48, height: 48, borderRadius: 12, background: "linear-gradient(135deg, oklch(0.30 0.10 200), oklch(0.18 0.06 230))", display: "grid", placeItems: "center", color: "var(--aurora)", border: "1px solid oklch(0.74 0.13 200 / 0.4)" }}>
              <I name="research" size={20} />
            </div>
            <div>
              <div className="h-title">Home services local SEO 2026 — what changed</div>
              <div className="muted fz-12 mt-2">For: Lawn Care, Hi-Tide Harry · Status: synthesized · 9 sources · {depth} pass</div>
            </div>
          </div>
          <div className="row gap-2">
            <Btn kind="ghost" icon="download">Export</Btn>
            <Btn icon="zap">Dig deeper</Btn>
            <Btn icon="arrowUpRight" kind="primary">Promote findings</Btn>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginTop: 14 }}>
          <Card>
            <Eyebrow>Opportunity 1 of 3</Eyebrow>
            <div className="fw-500 fz-13 mt-2">FAQ-rich service pages are outranking thin pages 3:1</div>
            <div className="muted fz-11 mt-2">Evidence: 6 of 9 top-ranked competitors. Avg FAQ count: 8. Schema present 9/9.</div>
            <div className="row gap-2 mt-3"><Chip tone="good">High confidence</Chip><Chip>+ pattern card</Chip></div>
          </Card>
          <Card>
            <Eyebrow>Opportunity 2 of 3</Eyebrow>
            <div className="fw-500 fz-13 mt-2">Service-area neighborhood pages drive long-tail discovery</div>
            <div className="muted fz-11 mt-2">Pattern: 1 page per neighborhood, 600+ words, embedded map.</div>
            <div className="row gap-2 mt-3"><Chip tone="aurora">Med confidence</Chip><Chip>+ component idea</Chip></div>
          </Card>
          <Card>
            <Eyebrow>Opportunity 3 of 3</Eyebrow>
            <div className="fw-500 fz-13 mt-2">Customer-photo galleries beat stock by 18% on time-on-page</div>
            <div className="muted fz-11 mt-2">Sample: 4 sites with native gallery, 5 with stock. Caveat: small N.</div>
            <div className="row gap-2 mt-3"><Chip tone="warn">Low confidence</Chip><Chip>flag for re-test</Chip></div>
          </Card>
        </div>
      </Card>

      {/* Workspace tabs */}
      <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr 1fr", gap: 12 }}>
        {/* Source library */}
        <Card>
          <div className="between mb-3"><div className="h-section">Source library</div><Btn kind="ghost" icon="plus">Add</Btn></div>
          <div className="col gap-2">
            {[
              { dom: "search.google.com/quality-rater-guidelines", q: "official", chip: "good" },
              { dom: "moz.com/blog/local-seo-2026", q: "industry", chip: "" },
              { dom: "the-best-lawn-care.netlify.app", q: "own portfolio", chip: "ember" },
              { dom: "competitor: greengrass-atl.com", q: "ranks #1", chip: "aurora" },
              { dom: "competitor: yardguys-buckhead.com", q: "ranks #3", chip: "aurora" },
              { dom: "reddit r/landscaping", q: "voice of customer", chip: "" },
            ].map((s, i) => (
              <div key={i} className="row gap-3" style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--hair)" }}>
                <div style={{ width: 22, height: 22, borderRadius: 4, background: "var(--panel-2)", display: "grid", placeItems: "center", color: "var(--ink-3)" }}><I name="globe" size={12} /></div>
                <div className="grow">
                  <div className="fz-12 mono" style={{ color: "var(--ink-2)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.dom}</div>
                  <div className="dim fz-11">{s.q}</div>
                </div>
                <Chip tone={s.chip}>{s.chip === "ember" ? "ours" : s.chip === "aurora" ? "competitor" : s.chip === "good" ? "primary" : "secondary"}</Chip>
              </div>
            ))}
          </div>
        </Card>

        {/* Competitive map */}
        <Card>
          <div className="between mb-3"><div className="h-section">Competitive map</div><Tag>5 competitors</Tag></div>
          <div style={{ position: "relative", height: 240, border: "1px solid var(--hair)", borderRadius: 10, background: "radial-gradient(60% 50% at 50% 50%, oklch(0.16 0.012 265 / 0.5), transparent 70%)" }}>
            <svg viewBox="0 0 240 240" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
              <line x1="120" y1="0" x2="120" y2="240" stroke="var(--hair)" />
              <line x1="0" y1="120" x2="240" y2="120" stroke="var(--hair)" />
              <text x="6" y="14" fill="var(--ink-4)" style={{ fontSize: 9, fontFamily: "var(--font-mono)" }}>← cheap</text>
              <text x="200" y="14" fill="var(--ink-4)" style={{ fontSize: 9, fontFamily: "var(--font-mono)" }}>premium →</text>
              <text x="6" y="234" fill="var(--ink-4)" style={{ fontSize: 9, fontFamily: "var(--font-mono)" }}>↓ thin pages</text>
            </svg>
            {[
              { x: 70, y: 165, label: "GreenGrass", chip: "aurora" },
              { x: 145, y: 95, label: "YardGuys", chip: "aurora" },
              { x: 195, y: 60, label: "Premier", chip: "aurora" },
              { x: 105, y: 55, label: "Lawn Care", chip: "ember" },
              { x: 50, y: 120, label: "Local LLC", chip: "" },
            ].map((p, i) => (
              <div key={i} style={{ position: "absolute", left: p.x, top: p.y, transform: "translate(-50%, -50%)" }}>
                <div className="row gap-2">
                  <Dot tone={p.chip} />
                  <span className="fz-11" style={{ color: p.chip === "ember" ? "var(--ember)" : "var(--ink-2)" }}>{p.label}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="dim fz-11 mt-3">Lawn Care sits in the empty premium-but-rich-content quadrant. Two opportunities map here.</div>
        </Card>

        {/* Pattern library */}
        <Card>
          <div className="between mb-3"><div className="h-section">Pattern library</div><Btn kind="ghost" icon="plus" /></div>
          <div className="col gap-2">
            {[
              { p: "FAQ-rich service page", evidence: "6 / 9 sites · high CTR", conf: "high" },
              { p: "Hero breakout 100vw", evidence: "internal · 4 sites", conf: "high" },
              { p: "Neighborhood landing pages", evidence: "3 / 9 sites · long tail", conf: "med" },
              { p: "Customer photo gallery", evidence: "4 sites · n=4", conf: "low" },
              { p: "Animated divider SVG", evidence: "9 / 9 sites", conf: "high" },
            ].map((pp, i) => (
              <div key={i} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--hair)" }}>
                <div className="row between">
                  <div className="fz-12 fw-500">{pp.p}</div>
                  <Chip tone={pp.conf === "high" ? "good" : pp.conf === "med" ? "aurora" : "warn"}>{pp.conf}</Chip>
                </div>
                <div className="dim fz-11 mt-2">{pp.evidence}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* opportunity matrix + briefs row */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 14 }}>
        <Card>
          <div className="between mb-3"><div className="h-section">Opportunity / gap analysis</div><Btn kind="ghost" icon="filter">Filter</Btn></div>
          <div className="col gap-2">
            {[
              { name: "FAQ schema across 6 service pages", impact: 80, effort: 25, route: "Sites" },
              { name: "Build 'service-area neighborhood' template", impact: 70, effort: 60, route: "Components" },
              { name: "Migrate stock heroes to commissioned photo", impact: 55, effort: 75, route: "Media" },
              { name: "Add customer review microdata", impact: 50, effort: 20, route: "Sites" },
            ].map((o, i) => (
              <div key={i} style={{ padding: 10, borderRadius: 8, border: "1px solid var(--hair)" }}>
                <div className="row between">
                  <div className="fz-12 fw-500">{o.name}</div>
                  <Chip>→ {o.route}</Chip>
                </div>
                <div className="row gap-3 mt-2 fz-11 dim">
                  <span style={{ width: 60 }}>Impact</span>
                  <div className="grow"><Meter value={o.impact} tone="good" /></div>
                  <span className="mono tabular" style={{ width: 30, textAlign: "right" }}>{o.impact}</span>
                </div>
                <div className="row gap-3 mt-2 fz-11 dim">
                  <span style={{ width: 60 }}>Effort</span>
                  <div className="grow"><Meter value={o.effort} tone="warn" /></div>
                  <span className="mono tabular" style={{ width: 30, textAlign: "right" }}>{o.effort}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <div className="between mb-3"><div className="h-section">Recent briefs</div><Btn kind="ghost" icon="arrowRight">All briefs</Btn></div>
          <div className="col gap-2">
            {[
              { t: "Home services local SEO 2026", d: "1h", chip: "ember" },
              { t: "Coastal hardware buyer behavior", d: "1d", chip: "" },
              { t: "Asheville artisan goods market", d: "3d", chip: "" },
              { t: "Hero breakout — does it convert?", d: "1w", chip: "good" },
              { t: "Component reuse vs solo build cost", d: "2w", chip: "" },
            ].map((b, i) => (
              <div key={i} className="row between" style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--hair)" }}>
                <div className="row gap-2">
                  <I name="doc" size={13} style={{ color: "var(--ink-3)" }} />
                  <span className="fz-12">{b.t}</span>
                </div>
                <div className="row gap-2"><Chip tone={b.chip}>{b.chip === "ember" ? "active" : b.chip === "good" ? "validated" : "archived"}</Chip><span className="dim fz-11 mono">{b.d}</span></div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

window.ScreenResearch = ScreenResearch;
