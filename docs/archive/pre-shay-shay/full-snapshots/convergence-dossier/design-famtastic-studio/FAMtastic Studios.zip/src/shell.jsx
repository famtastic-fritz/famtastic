/* App shell: left rail + topbar + bottom strip + right panel */

const NAV = [
  { id: "home",      label: "Home",            icon: "home" },
  { id: "sites",     label: "Sites",           icon: "sites",      kind: "section" },
  { id: "thinktank", label: "Think-Tank",      icon: "brain" },
  { id: "research",  label: "Research Center", icon: "research" },
  { id: "components",label: "Component Studio",icon: "components" },
  { id: "media",     label: "Media Studio",    icon: "media" },
  { id: "shay",      label: "Shay Shay",       icon: "shay" },
  { id: "mission",   label: "Mission Control", icon: "mission" },
  { id: "settings",  label: "Settings",        icon: "settings",   kind: "footer" },
];

function Rail({ active, onSelect }) {
  const top = NAV.filter(n => n.kind !== "footer");
  const foot = NAV.filter(n => n.kind === "footer");
  return (
    <aside className="rail">
      <div className="rail-mark" title="FAMtastic">F</div>
      {top.map(n => (
        <div key={n.id}
             className={`rail-item ${active === n.id ? "active" : ""}`}
             onClick={() => onSelect(n.id)}>
          <I name={n.icon} size={18} />
          <span className="rail-tooltip">{n.label}</span>
        </div>
      ))}
      <div className="rail-spacer" />
      {foot.map(n => (
        <div key={n.id}
             className={`rail-item ${active === n.id ? "active" : ""}`}
             onClick={() => onSelect(n.id)}>
          <I name={n.icon} size={18} />
          <span className="rail-tooltip">{n.label}</span>
        </div>
      ))}
      <div style={{ marginTop: 8 }}>
        <Avatar kind="fritz" initials="F" />
      </div>
    </aside>
  );
}

function Topbar({ section, project, site, onSelect }) {
  const labels = Object.fromEntries(NAV.map(n => [n.id, n.label]));
  return (
    <div className="topbar">
      <div className="crumb">
        <span className="muted">{project}</span>
        <I name="chev" size={12} />
        <b>{site}</b>
        <I name="chev" size={12} />
        <span style={{ color: "var(--ink-2)" }}>{labels[section] || ""}</span>
      </div>

      <div className="row gap-2" style={{ marginLeft: 18 }}>
        <button className="btn btn-ghost"><I name="search" /> <span className="dim">Search anything</span> <span className="kbd">⌘K</span></button>
      </div>

      <div className="status">
        <span className="item"><Dot tone="good" /> Build queue<span className="mono tabular dim" style={{ marginLeft: 6 }}>2 / 6</span></span>
        <span className="item"><I name="cube" size={13} /> claude-sonnet-4.5 <span className="dim mono">· haiku-4.5</span></span>
        <span className="item mono tabular"><span className="dim">$</span>14.82 today<span className="dim"> / $50 cap</span></span>
        <span className="item"><I name="bell" size={13} /></span>
        <span className="item"><Avatar kind="fritz" initials="F" /></span>
      </div>
    </div>
  );
}

/* Bottom memory strip — recent actions, run state, learning captures */
const STRIP_DEFAULT = [
  { t: "00:42", who: "Shay", text: "Saved Hi-Tide Harry assistant v0.4 to Component Studio.", kind: "save", run: "rn-91c" },
  { t: "01:14", who: "Run",  text: "Auntie Gale → /shop regen complete · 7 slots filled · 2 deferred.", kind: "run", run: "rn-92a" },
  { t: "01:18", who: "Media",text: "Generated 6 variants — 'amber dusk lawn, low sun'.", kind: "media" },
  { t: "01:22", who: "Learn",text: "Captured: hero-breakout w/ 100vw improves above-fold density on dense niches.", kind: "learn" },
  { t: "01:28", who: "Shay", text: "Drafted research brief for 'home services local SEO 2026'.", kind: "research" },
];

function MemoryStrip({ items = STRIP_DEFAULT }) {
  const tone = (k) => ({
    save: "good", run: "ember", media: "aurora", learn: "shay", research: "info",
  }[k] || "");
  return (
    <div className="strip">
      <div className="row gap-2" style={{ flexShrink: 0 }}>
        <I name="history" size={14} style={{ color: "var(--ink-3)" }} />
        <span className="eyebrow">Memory</span>
      </div>
      <div className="vdivider" style={{ height: 28 }} />
      <div className="row" style={{ overflow: "hidden", flex: 1, gap: 18, position: "relative" }}>
        {items.map((it, i) => (
          <div key={i} className="row gap-2" style={{ flexShrink: 0, fontSize: 11 }}>
            <span className="mono dim tabular">{it.t}</span>
            <Dot tone={tone(it.kind)} />
            <span className="muted">{it.who}</span>
            <span style={{ color: "var(--ink-2)", maxWidth: 360, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {it.text}
            </span>
            {it.run ? <Tag>{it.run}</Tag> : null}
          </div>
        ))}
      </div>
      <div className="row gap-2" style={{ flexShrink: 0 }}>
        <button className="btn btn-ghost"><I name="play" size={12} /> Replay</button>
        <button className="btn btn-ghost"><I name="bookmark" size={12} /> Pin</button>
        <button className="btn btn-ghost"><I name="more" size={14} /></button>
      </div>
    </div>
  );
}

/* Right contextual panel — default Inspector / Shay context */
function ContextPanel({ section, custom }) {
  if (custom) return <aside className="right-panel">{custom}</aside>;

  return (
    <aside className="right-panel">
      <div className="p-4" style={{ borderBottom: "1px solid var(--hair)" }}>
        <div className="row between">
          <div className="row gap-2">
            <Avatar kind="shay" initials="S" />
            <div>
              <div className="fz-13 fw-500">Shay</div>
              <div className="dim fz-11">Operator · context-aware</div>
            </div>
          </div>
          <div className="row gap-2">
            <button className="btn btn-ghost btn-icon"><I name="diff" size={14} /></button>
            <button className="btn btn-ghost btn-icon"><I name="x" size={14} /></button>
          </div>
        </div>
        <div className="seg mt-3">
          <button className="on">Short</button>
          <button>Operator</button>
          <button>Deep</button>
          <button>Next</button>
        </div>
      </div>

      <div className="p-4" style={{ flex: 1, overflow: "auto" }}>
        <ChatBubble who="shay" meta="just now">
          You're on the Platform Home. Two builds are mid-run. The Auntie Gale shop page is waiting on 2 deferred images. Want me to either generate them in Media Studio or continue without?
        </ChatBubble>

        <Card style={{ marginBottom: 12 }}>
          <Eyebrow>Next recommended action</Eyebrow>
          <div className="fw-500 mt-2 fz-13">Generate 2 deferred shop images for Auntie Gale</div>
          <div className="muted fz-11 mt-2">Will use Firefly · est. $0.18 · ~30s. Slots: <Tag>shop-hero</Tag> <Tag>seasonal-bundle</Tag></div>
          <div className="row gap-2 mt-3">
            <button className="btn btn-primary"><I name="zap" size={12} /> Run</button>
            <button className="btn">Open Media Studio</button>
          </div>
        </Card>

        <Card>
          <div className="row between mb-3">
            <Eyebrow>Capability truth</Eyebrow>
            <Chip tone="good">Honest</Chip>
          </div>
          <div className="col gap-2 fz-12">
            <div className="row between"><span>Site builds</span><span className="muted">verified · 6 shipped</span></div>
            <div className="row between"><span>Image gen</span><span className="muted">verified · 4 providers</span></div>
            <div className="row between"><span>Component reuse</span><span style={{ color: "var(--warn)" }}>partial · 3/8 sites</span></div>
            <div className="row between"><span>A/B testing</span><span className="dim">not yet capable</span></div>
          </div>
        </Card>

        <div className="mt-3">
          <Eyebrow>Route this to…</Eyebrow>
          <div className="row gap-2 mt-2" style={{ flexWrap: "wrap" }}>
            {["Sites","Research","Media","Components","Mission Control"].map(t => (
              <button key={t} className="btn btn-ghost" style={{ fontSize: 11 }}>{t}</button>
            ))}
          </div>
        </div>
      </div>

      <div className="p-3" style={{ borderTop: "1px solid var(--hair)", display: "flex", gap: 8 }}>
        <input className="input" placeholder="Ask Shay…  ⌘ to readback" />
        <button className="btn btn-primary btn-icon"><I name="send" size={14} /></button>
      </div>
    </aside>
  );
}

/* Floating Shay bubble */
function ShayBubble({ onClick }) {
  return <div className="shay-bubble" onClick={onClick} title="Shay">S</div>;
}

Object.assign(window, { NAV, Rail, Topbar, MemoryStrip, ContextPanel, ShayBubble });
