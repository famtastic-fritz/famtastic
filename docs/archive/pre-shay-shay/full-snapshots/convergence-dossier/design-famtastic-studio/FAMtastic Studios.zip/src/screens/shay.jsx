/* Shay Shay — assistant workspace */

function ScreenShay() {
  const [mode, setMode] = React.useState("Operator");
  return (
    <div className="fade-up" style={{ height: "calc(100vh - 52px - 64px - 56px)", display: "grid", gridTemplateColumns: "1.4fr 360px", gap: 14 }}>
      <Card style={{ padding: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div className="p-3" style={{ borderBottom: "1px solid var(--hair)" }}>
          <div className="row between">
            <div className="row gap-3">
              <div style={{ width: 44, height: 44, borderRadius: "50%", background: "radial-gradient(circle at 35% 25%, oklch(0.95 0.10 90), oklch(0.65 0.15 70))", display: "grid", placeItems: "center", color: "oklch(0.20 0.04 70)", fontFamily: "var(--font-serif)", fontSize: 22, boxShadow: "0 0 0 1px oklch(0.82 0.12 90 / 0.4), 0 8px 26px -8px oklch(0.82 0.12 90 / 0.5)" }}>S</div>
              <div>
                <div className="serif" style={{ fontSize: 22 }}>Shay</div>
                <div className="dim fz-11">Operator · context-aware · routes work</div>
              </div>
            </div>
            <div className="seg" title="Readback mode">
              {["Short","Operator","Deep","Next-action"].map(m => <button key={m} className={mode === m ? "on" : ""} onClick={() => setMode(m)}>{m}</button>)}
            </div>
          </div>
        </div>

        <div style={{ flex: 1, overflow: "auto", padding: 18 }}>
          <div className="row gap-2 mb-4" style={{ flexWrap: "wrap" }}>
            <Chip tone="shay">Knows current screen</Chip>
            <Chip>5 sites loaded</Chip>
            <Chip>14 components</Chip>
            <Chip>184 assets</Chip>
            <Chip>12 briefs</Chip>
          </div>

          <ChatBubble who="fritz" meta="now">
            What's the state of Auntie Gale and what should I do next?
          </ChatBubble>

          {mode === "Operator" && (
            <ChatBubble who="shay" meta="reading state">
              <div>
                <p style={{ margin: 0 }}>Auntie Gale is at <b>86%</b>. Template is locked. Five sections built, two image slots deferred — <Tag>shop-hero</Tag> and <Tag>seasonal-bundle</Tag>. No nav drift. No verify regressions.</p>
                <p>Next move: generate those two images in Media Studio (~$0.18, 30s), approve in review, then run <code className="mono">/shop regen</code>. Total to publish: <b>~6 min</b>.</p>
              </div>
            </ChatBubble>
          )}
          {mode === "Short" && (
            <ChatBubble who="shay" meta="short">
              86%. Two images deferred. Generate, approve, regen — 6 min to ship.
            </ChatBubble>
          )}
          {mode === "Deep" && (
            <ChatBubble who="shay" meta="deep">
              <div className="col gap-2">
                <p style={{ margin: 0 }}>Auntie Gale (<Tag>site-auntie-gale</Tag>) is in the build phase. The template emit went clean on first pass — logo extraction produced all three SVGs, peak dividers re-used across 5 pages, hero vocabulary at v2.1.</p>
                <p style={{ margin: 0 }}>Two image slots remain: <Tag>shop-hero</Tag> and <Tag>seasonal-bundle</Tag>. Both deferred earlier because the product list wasn't final. The product list is now final (Fritz approved May 11, 18:42). I can run a Firefly pass with the warm-market style we've been using.</p>
                <p style={{ margin: 0 }}>Risk: none. Cost: $0.18. Time: 30s. The /shop regen takes ~4 min after approval. <i className="muted">No new components needed; everything is in the library.</i></p>
              </div>
            </ChatBubble>
          )}
          {mode === "Next-action" && (
            <ChatBubble who="shay" meta="next">
              <div className="row gap-2"><Btn icon="zap" kind="primary">Generate 2 images</Btn><span className="dim fz-12">~$0.18 · 30s · then approve · then publish</span></div>
            </ChatBubble>
          )}

          <ChatBubble who="fritz" meta="now">
            What did I learn this week worth saving?
          </ChatBubble>

          <ChatBubble who="shay" meta="learning capture">
            <div className="col gap-2">
              <p style={{ margin: 0 }}>Three candidates from this week. All low-risk to add to <Tag>famtastic-dna.md</Tag>:</p>
              <Card style={{ background: "oklch(0.13 0.012 265)", padding: 10 }}>
                <div className="row between"><span className="fz-12 fw-500">Hero breakout improves above-fold density on dense niches</span><Chip tone="good">high</Chip></div>
                <div className="dim fz-11 mt-2">Source: Lawn Care vs Hi-Tide A/B internal · 4 sessions</div>
                <div className="row gap-2 mt-3"><Btn>Add to DNA</Btn><Btn kind="ghost">Mark for re-test</Btn></div>
              </Card>
              <Card style={{ background: "oklch(0.13 0.012 265)", padding: 10 }}>
                <div className="row between"><span className="fz-12 fw-500">FAQ schema is the highest-impact, lowest-effort SEO win</span><Chip tone="good">high</Chip></div>
                <div className="dim fz-11 mt-2">Source: research brief "home services local SEO 2026"</div>
                <div className="row gap-2 mt-3"><Btn>Add to DNA</Btn><Btn kind="ghost">Promote to component</Btn></div>
              </Card>
              <Card style={{ background: "oklch(0.13 0.012 265)", padding: 10 }}>
                <div className="row between"><span className="fz-12 fw-500">Customer photos beat stock — but n is small, hold</span><Chip tone="warn">med</Chip></div>
                <div className="dim fz-11 mt-2">Source: research · n=4. Don't promote yet.</div>
                <div className="row gap-2 mt-3"><Btn kind="ghost">Schedule re-test</Btn></div>
              </Card>
            </div>
          </ChatBubble>
        </div>
        <div className="p-3" style={{ borderTop: "1px solid var(--hair)", display: "flex", gap: 8 }}>
          <input className="input" placeholder="Ask Shay anything — she'll route or readback…" />
          <Btn icon="send" kind="primary" />
        </div>
      </Card>

      {/* Right: route panel */}
      <div className="col gap-3" style={{ overflow: "auto" }}>
        <Card>
          <Eyebrow>Route this thread to…</Eyebrow>
          <div className="col gap-2 mt-2">
            {[
              { name: "Sites · Auntie Gale build", icon: "sites", chip: "ember" },
              { name: "Research · expand FAQ schema brief", icon: "research", chip: "" },
              { name: "Media · generate 2 deferred images", icon: "media", chip: "ember" },
              { name: "Components · FAQ accordion lookup", icon: "components", chip: "" },
              { name: "Mission Control · schedule run", icon: "mission", chip: "" },
            ].map((r, i) => (
              <div key={i} className="row between" style={{ padding: "10px 12px", borderRadius: 8, border: "1px solid var(--hair)" }}>
                <div className="row gap-2"><I name={r.icon} size={13} /><span className="fz-12">{r.name}</span></div>
                {r.chip ? <Chip tone={r.chip}>recommended</Chip> : <Btn kind="ghost" icon="arrowRight" />}
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <Eyebrow>Explain current screen</Eyebrow>
          <div className="muted fz-12 mt-2">Shay knows where you are and what's loaded. Ask: <i>"why is this slot deferred?"</i>, <i>"what would you change?"</i>, or <i>"who used this component last?"</i></div>
          <div className="row gap-2 mt-3"><Btn icon="search">Explain</Btn><Btn icon="diff">Compare</Btn></div>
        </Card>

        <Card>
          <div className="between mb-3"><Eyebrow>Knowledge sources</Eyebrow><Tag>auto-loaded</Tag></div>
          <div className="col gap-2 fz-11">
            {[
              { f: "famtastic-dna.md", d: "build patterns" },
              { f: "patterns.md", d: ".brain validated" },
              { f: "anti-patterns.md", d: ".brain regressions" },
              { f: "SITE-LEARNINGS.md", d: "31 entries" },
              { f: "STUDIO-CONTEXT.md", d: "current state" },
            ].map((s, i) => (
              <div key={i} className="row between" style={{ padding: "6px 8px", borderRadius: 6, border: "1px solid var(--hair)" }}>
                <div className="row gap-2"><I name="doc" size={12} /><span className="mono">{s.f}</span></div>
                <span className="dim">{s.d}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

window.ScreenShay = ScreenShay;
