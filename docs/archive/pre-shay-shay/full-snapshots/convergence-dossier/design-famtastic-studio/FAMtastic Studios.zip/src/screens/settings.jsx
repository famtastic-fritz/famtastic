/* Settings — platform-wide */

function ScreenSettings() {
  const groups = [
    { id: "models",    label: "Models & providers", icon: "cube" },
    { id: "cost",      label: "Cost & approvals",   icon: "bolt" },
    { id: "media",     label: "Media defaults",     icon: "media" },
    { id: "components",label: "Component defaults", icon: "components" },
    { id: "sites",     label: "Site defaults",      icon: "sites" },
    { id: "deploy",    label: "Deployment",         icon: "globe" },
    { id: "theme",     label: "Theme & workspace",  icon: "spark" },
    { id: "memory",    label: "Memory & learning",  icon: "history" },
  ];

  return (
    <div className="fade-up" style={{ display: "grid", gridTemplateColumns: "240px 1fr", gap: 14 }}>
      {/* Sidebar */}
      <Card style={{ padding: 0, alignSelf: "start", position: "sticky", top: 0 }}>
        <div className="p-3" style={{ borderBottom: "1px solid var(--hair)" }}>
          <div className="h-section">Platform settings</div>
          <div className="dim fz-11 mt-2">Defaults flow into every site unless overridden locally.</div>
        </div>
        <div className="col" style={{ padding: 8 }}>
          {groups.map((g, i) => (
            <a key={g.id} className="row gap-2" style={{ padding: "8px 10px", borderRadius: 8, color: i === 0 ? "var(--ember)" : "var(--ink-2)", background: i === 0 ? "oklch(0.78 0.14 65 / 0.10)" : "transparent", fontSize: 12, cursor: "pointer" }}>
              <I name={g.icon} size={14} />
              <span>{g.label}</span>
            </a>
          ))}
        </div>
      </Card>

      <div className="col gap-3">
        {/* Models & providers */}
        <Card>
          <SectionHeader eyebrow="Models & providers" title="Pick the brains." style={{ marginBottom: 14 }} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            <Field label="Builder model" sub="long-context, plans the build">
              <Seg items={["sonnet-4.5","opus-4.5","local-llama"]} value="sonnet-4.5" onChange={() => {}} />
            </Field>
            <Field label="Operator readback" sub="fast summaries">
              <Seg items={["haiku-4.5","sonnet-4.5"]} value="haiku-4.5" onChange={() => {}} />
            </Field>
            <Field label="Image provider chain">
              <div className="row gap-2 mono fz-11">
                <Tag>Firefly</Tag><I name="arrowRight" size={11} /><Tag>Imagen</Tag><I name="arrowRight" size={11} /><Tag>Mid-J</Tag><I name="arrowRight" size={11} /><Tag>Local SD</Tag>
              </div>
            </Field>
            <Field label="Web research"><Seg items={["Brave","Google","Bing"]} value="Brave" onChange={() => {}} /></Field>
          </div>
        </Card>

        {/* Cost / approvals */}
        <Card>
          <SectionHeader eyebrow="Cost & approvals" title="Spend with intent." style={{ marginBottom: 14 }} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14 }}>
            <Field label="Daily cap"><input className="input mono tabular" defaultValue="$50.00" /></Field>
            <Field label="Per-run cap" sub="approval required above"><input className="input mono tabular" defaultValue="$5.00" /></Field>
            <Field label="Auto-approve under"><input className="input mono tabular" defaultValue="$0.50" /></Field>
            <Field label="Notify when remaining"><input className="input mono tabular" defaultValue="$10.00" /></Field>
            <Field label="Stop on failed retry × N"><input className="input mono tabular" defaultValue="3" /></Field>
            <Field label="Honest cost ledger" sub="show real spend, not estimates"><Toggle on={true} /></Field>
          </div>
        </Card>

        {/* Media + components + sites + deploy compact rows */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
          <Card>
            <div className="h-section mb-3">Media defaults</div>
            <div className="col gap-3">
              <Field label="Default style"><input className="input" defaultValue="Editorial · warm light · 35mm grain" /></Field>
              <Field label="Slot identity (data-slot-id)"><Toggle on={true} label="locked on" /></Field>
              <Field label="Auto-fill missing slots"><Toggle on={true} /></Field>
              <Field label="Save all variants to library"><Toggle on={true} /></Field>
            </div>
          </Card>
          <Card>
            <div className="h-section mb-3">Component defaults</div>
            <div className="col gap-3">
              <Field label="Reuse policy"><Seg items={["Search first","Always create"]} value="Search first" onChange={() => {}} /></Field>
              <Field label="Required test states">
                <div className="row gap-2" style={{ flexWrap: "wrap" }}>
                  {["empty","loading","error","filled","hover","focus"].map(s => <Chip key={s} tone="aurora">{s}</Chip>)}
                </div>
              </Field>
              <Field label="Promote to locked above N uses"><input className="input mono tabular" defaultValue="3" /></Field>
            </div>
          </Card>
          <Card>
            <div className="h-section mb-3">Site defaults</div>
            <div className="col gap-3">
              <Field label="Build mode" sub="locked"><Tag tone="ember">template-first</Tag></Field>
              <Field label="Hero vocabulary"><Tag tone="ember">fam-hero-layered v2.1</Tag></Field>
              <Field label="Section divider default"><Seg items={["wave","tilt","peak","arch"]} value="peak" onChange={() => {}} /></Field>
              <Field label="Min above-fold sections"><input className="input mono tabular" defaultValue="2" /></Field>
            </div>
          </Card>
          <Card>
            <div className="h-section mb-3">Deployment</div>
            <div className="col gap-3">
              <Field label="Default target"><Seg items={["Netlify","Vercel","S3","Manual"]} value="Netlify" onChange={() => {}} /></Field>
              <Field label="Auto-publish on green checks"><Toggle on={false} label="off · Shay asks first" /></Field>
              <Field label="Drive sync (proofs + briefs)"><Toggle on={true} /></Field>
            </div>
          </Card>
        </div>

        {/* Theme */}
        <Card>
          <SectionHeader eyebrow="Theme & workspace" title="Set the room." style={{ marginBottom: 14 }} />
          <div className="row gap-3">
            {[
              { name: "Out of darkness", chip: "ember", active: true, swatch: "linear-gradient(135deg, oklch(0.10 0.010 265), oklch(0.78 0.14 65))" },
              { name: "Studio noir", chip: "", swatch: "linear-gradient(135deg, oklch(0.08 0.005 265), oklch(0.40 0.005 265))" },
              { name: "Daylight", chip: "", swatch: "linear-gradient(135deg, oklch(0.96 0.005 265), oklch(0.78 0.14 65))" },
              { name: "Aurora", chip: "", swatch: "linear-gradient(135deg, oklch(0.10 0.010 265), oklch(0.74 0.13 200))" },
            ].map((t, i) => (
              <Card key={i} hover style={{ flex: 1, padding: 0, overflow: "hidden", border: t.active ? "1px solid oklch(0.78 0.14 65 / 0.5)" : "1px solid var(--hair)" }}>
                <div style={{ height: 80, background: t.swatch }} />
                <div className="p-3 row between">
                  <div className="fz-12 fw-500">{t.name}</div>
                  {t.active ? <Chip tone="ember">active</Chip> : <Btn kind="ghost">Use</Btn>}
                </div>
              </Card>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

window.ScreenSettings = ScreenSettings;
