/* Site Builder Workspace */

function ScreenSiteBuilder() {
  const [tab, setTab] = React.useState("Structure");
  const [device, setDevice] = React.useState("Desktop");
  const [selected, setSelected] = React.useState("hero");

  return (
    <div className="fade-up" style={{ height: "calc(100vh - 52px - 64px - 56px)", display: "grid", gridTemplateColumns: "320px 1fr 380px", gap: 14 }}>
      {/* Left: chat / build with Shay */}
      <Card style={{ padding: 0, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div className="p-3" style={{ borderBottom: "1px solid var(--hair)" }}>
          <div className="row between">
            <div className="row gap-2">
              <Avatar kind="shay" initials="S" />
              <div>
                <div className="fw-500 fz-13">Build with Shay</div>
                <div className="dim fz-11">Auntie Gale · template-first</div>
              </div>
            </div>
            <Btn kind="ghost" icon="more" />
          </div>
          <div className="seg mt-3">
            <button className="on">Build</button>
            <button>Refine</button>
            <button>Q&amp;A</button>
          </div>
        </div>
        <div className="p-3" style={{ flex: 1, overflow: "auto" }}>
          <ChatBubble who="fritz" meta="07:12">
            Make the shop hero feel like a Sunday market — warm light, hand-painted signage feel.
          </ChatBubble>
          <ChatBubble who="shay" meta="07:12">
            On it. I'll keep the four-layer hero (<Tag>--bg</Tag> <Tag>--fx</Tag> <Tag>--character</Tag> <Tag>--content</Tag>). I'll route the bg image to Media Studio, draft 6 variants, and hold a "morning haze" particle pass on <Tag>--fx</Tag>.
          </ChatBubble>
          <Card style={{ background: "oklch(0.13 0.012 265)", padding: 10, borderColor: "var(--hair-2)" }}>
            <Eyebrow>Plan</Eyebrow>
            <div className="col gap-2 mt-2 fz-12">
              <div className="row gap-2"><Dot tone="good" /><span>Generate 6 hero bg variants</span><span className="dim mono" style={{ marginLeft: "auto" }}>~$0.36</span></div>
              <div className="row gap-2"><Dot tone="good" /><span>Apply morning-haze particle pass</span></div>
              <div className="row gap-2"><Dot /><span>Re-emit hero copy with market voice</span></div>
              <div className="row gap-2"><Dot /><span>Verify no nav drift across pages</span></div>
            </div>
            <div className="row gap-2 mt-3">
              <Btn icon="check" kind="primary">Approve plan</Btn>
              <Btn kind="ghost">Edit</Btn>
            </div>
          </Card>
          <ChatBubble who="shay" meta="07:13">
            One question: the lawn care site uses a peak divider. Want me to keep that consistent across portfolio, or use an arch divider here?
          </ChatBubble>
          <div className="row gap-2 mt-2" style={{ marginLeft: 32 }}>
            <Btn>Use peak</Btn>
            <Btn>Use arch</Btn>
            <Btn kind="ghost">Show me both</Btn>
          </div>
        </div>
        <div className="p-3" style={{ borderTop: "1px solid var(--hair)" }}>
          <div className="row gap-2 mb-2 dim fz-11">
            <I name="attach" size={12} />
            <span>Attach research brief, image, or component</span>
          </div>
          <div className="row gap-2">
            <input className="input" placeholder="Tell Shay what to do…" />
            <Btn icon="send" kind="primary" />
          </div>
        </div>
      </Card>

      {/* Center: page/section structure */}
      <div style={{ display: "flex", flexDirection: "column", overflow: "hidden", gap: 10 }}>
        <Card style={{ padding: 10 }}>
          <div className="row between">
            <div className="row gap-2">
              <Tabs items={["Structure","Pages","Versions","Verify"]} value={tab} onChange={setTab} />
            </div>
            <div className="row gap-2">
              <span className="dim fz-11 mono">site-auntie-gale</span>
              <Tag>tag · ag-shop</Tag>
              <Btn kind="ghost" icon="branch">v0.4</Btn>
              <Btn kind="ghost" icon="history" />
              <Btn icon="play" kind="primary">Build /shop</Btn>
            </div>
          </div>
        </Card>

        <Card style={{ padding: 0, flex: 1, overflow: "hidden", display: "flex", flexDirection: "column" }}>
          <div className="row between p-3" style={{ borderBottom: "1px solid var(--hair)" }}>
            <div className="row gap-2 fz-12 muted">
              <I name="doc" size={13} />
              <span>/shop</span>
              <span className="dim">·</span>
              <span>5 sections</span>
              <span className="dim">·</span>
              <Chip tone="warn">2 deferred slots</Chip>
            </div>
            <div className="row gap-2">
              <button className="btn btn-ghost btn-icon"><I name="zap" size={14} /></button>
              <button className="btn btn-ghost btn-icon"><I name="copy" size={14} /></button>
              <button className="btn btn-ghost btn-icon"><I name="trash" size={14} /></button>
            </div>
          </div>

          <div style={{ flex: 1, overflow: "auto", padding: "12px 14px" }}>
            {[
              { id: "hero", name: "fam-hero-layered", v: "v2.1", slots: ["hero-bg","hero-character"], status: "ready", note: "Component lock — variants in Studio" },
              { id: "intro", name: "section-intro · two-col", v: "v1.0", slots: ["intro-image"], status: "ready" },
              { id: "grid", name: "product-grid · breakout", v: "v1.4", slots: ["product-1","product-2","product-3","product-4","product-5","product-6"], status: "missing", note: "2 of 6 image slots deferred" },
              { id: "feat", name: "feature-strip · seasonal", v: "v0.9", slots: ["seasonal-bundle"], status: "missing", note: "1 image slot deferred" },
              { id: "cta", name: "cta-band · shop", v: "v1.1", slots: [], status: "ready" },
            ].map((s, i) => {
              const sel = s.id === selected;
              return (
                <div key={i} onClick={() => setSelected(s.id)}
                     style={{
                       display: "grid", gridTemplateColumns: "32px 1fr 220px 100px",
                       gap: 12, padding: "12px 12px",
                       borderRadius: 10, marginBottom: 8, cursor: "pointer",
                       border: sel ? "1px solid oklch(0.78 0.14 65 / 0.4)" : "1px solid var(--hair)",
                       background: sel ? "linear-gradient(180deg, oklch(0.78 0.14 65 / 0.06), transparent)" : "oklch(0.13 0.012 265 / 0.4)",
                     }}>
                  <div style={{ display: "grid", placeItems: "center", color: "var(--ink-3)" }}>
                    <I name="cube" size={14} />
                  </div>
                  <div>
                    <div className="row gap-2">
                      <span className="fw-500 fz-13">{s.name}</span>
                      <span className="mono dim fz-11">{s.v}</span>
                    </div>
                    {s.note ? <div className="muted fz-11 mt-2">{s.note}</div> : <div className="dim fz-11 mt-2">Section ready</div>}
                  </div>
                  <div className="row gap-2" style={{ flexWrap: "wrap" }}>
                    {s.slots.slice(0, 4).map(sl => <Tag key={sl}>{sl}</Tag>)}
                    {s.slots.length > 4 ? <Tag>+{s.slots.length - 4}</Tag> : null}
                    {s.slots.length === 0 ? <span className="dim fz-11">no slots</span> : null}
                  </div>
                  <div className="row gap-2" style={{ justifyContent: "flex-end" }}>
                    {s.status === "missing"
                      ? <Chip tone="warn">missing</Chip>
                      : <Chip tone="good">ready</Chip>}
                  </div>
                </div>
              );
            })}

            <div style={{ display: "grid", gridTemplateColumns: "32px 1fr 100px", gap: 12, padding: "10px 12px", borderRadius: 10, border: "1px dashed var(--hair-2)", color: "var(--ink-3)", marginTop: 12 }}>
              <div style={{ display: "grid", placeItems: "center" }}><I name="plus" size={14} /></div>
              <div className="fz-12">Add a section — type a description or pick a component</div>
              <div style={{ textAlign: "right" }}><span className="dim mono fz-11">⌘ + N</span></div>
            </div>
          </div>
        </Card>
      </div>

      {/* Right: live preview / inspector */}
      <Card style={{ padding: 0, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div className="row between p-3" style={{ borderBottom: "1px solid var(--hair)" }}>
          <div className="seg">
            <button className={device === "Desktop" ? "on" : ""} onClick={() => setDevice("Desktop")}><I name="monitor" size={12} /></button>
            <button className={device === "Mobile" ? "on" : ""} onClick={() => setDevice("Mobile")}><I name="phone" size={12} /></button>
          </div>
          <div className="row gap-2">
            <button className="btn btn-ghost btn-icon"><I name="refresh" size={13} /></button>
            <button className="btn btn-ghost btn-icon"><I name="arrowUpRight" size={13} /></button>
          </div>
        </div>

        {/* Preview canvas */}
        <div style={{ padding: 14, display: "flex", justifyContent: "center", borderBottom: "1px solid var(--hair)" }}>
          <div style={{ width: device === "Mobile" ? 180 : "100%", maxWidth: 320, position: "relative" }}>
            {/* fake page preview */}
            <div style={{ borderRadius: 10, overflow: "hidden", border: "1px solid var(--hair-2)" }}>
              <div style={{ height: 14, background: "oklch(0.10 0.010 265)", borderBottom: "1px solid var(--hair)", display: "flex", alignItems: "center", padding: "0 8px", gap: 4 }}>
                <span className="dot" style={{ background: "oklch(0.66 0.20 25)" }} />
                <span className="dot" style={{ background: "oklch(0.80 0.14 80)" }} />
                <span className="dot" style={{ background: "oklch(0.74 0.14 155)" }} />
              </div>
              <MediaTile seed={5} ratio="16 / 11" label="" />
              <div style={{ padding: 10, background: "oklch(0.16 0.012 265)" }}>
                <Skel w="60%" h={10} />
                <Skel w="40%" h={8} style={{ marginTop: 6 }} />
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 6, marginTop: 10 }}>
                  <MediaTile seed={11} ratio="1 / 1" />
                  <MediaTile seed={12} ratio="1 / 1" />
                  <div style={{ aspectRatio: "1 / 1", border: "1px dashed oklch(0.80 0.14 80 / 0.6)", borderRadius: 6, display: "grid", placeItems: "center", color: "var(--warn)", fontSize: 9 }}>missing</div>
                </div>
              </div>
            </div>
            <Hint style={{ left: -2, top: 56, transform: "rotate(-1deg)" }}>Selected · hero-bg</Hint>
          </div>
        </div>

        {/* Inspector */}
        <div className="p-3" style={{ flex: 1, overflow: "auto" }}>
          <div className="between mb-3">
            <div className="h-section">Inspector</div>
            <Tag>fam-hero-layered v2.1</Tag>
          </div>
          <div className="col gap-3">
            <Field label="Layers">
              <div className="col gap-2">
                {["--bg","--fx","--character","--content"].map((l,i) => (
                  <div key={l} className="row between" style={{ padding: "6px 8px", borderRadius: 6, border: "1px solid var(--hair)" }}>
                    <div className="row gap-2">
                      <Tag tone="ember">{l}</Tag>
                      <span className="dim fz-11">{["amber-dusk-04","morning-haze","silhouette-02","headline-stack"][i]}</span>
                    </div>
                    <div className="row gap-2">
                      <button className="btn btn-ghost btn-icon"><I name="eye" size={12} /></button>
                      <button className="btn btn-ghost btn-icon"><I name="edit" size={12} /></button>
                    </div>
                  </div>
                ))}
              </div>
            </Field>

            <Field label="Slots">
              <div className="col gap-2">
                <Slot filled><Tag>hero-bg</Tag><span className="dim fz-11" style={{ marginLeft: "auto" }}>amber-dusk-04 · approved</span></Slot>
                <Slot filled><Tag>hero-character</Tag><span className="dim fz-11" style={{ marginLeft: "auto" }}>silhouette-02</span></Slot>
              </div>
            </Field>

            <Field label="Actions">
              <div className="row gap-2" style={{ flexWrap: "wrap" }}>
                <Btn icon="search">Inspect</Btn>
                <Btn icon="edit">Edit copy</Btn>
                <Btn icon="refresh">Refine</Btn>
                <Btn icon="zap">Regenerate</Btn>
                <Btn icon="bookmark">Save version</Btn>
              </div>
            </Field>

            <Field label="Verify">
              <div className="col gap-2 fz-12">
                <div className="row between"><span><Dot tone="good" /> BEM double-dash</span><span className="dim">passes</span></div>
                <div className="row between"><span><Dot tone="good" /> Logo single-emit</span><span className="dim">passes</span></div>
                <div className="row between"><span><Dot tone="warn" /> Image slots filled</span><span className="dim">2 deferred</span></div>
                <div className="row between"><span><Dot tone="good" /> No overflow-x clip</span><span className="dim">passes</span></div>
              </div>
            </Field>
          </div>
        </div>
      </Card>
    </div>
  );
}

window.ScreenSiteBuilder = ScreenSiteBuilder;
