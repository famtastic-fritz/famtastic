/* Component Studio */

const COMP_LIB = [
  { name: "fam-hero-layered", v: "v2.1", chip: "good", uses: 6, slots: 4, kind: "Hero" },
  { name: "section-intro · two-col", v: "v1.0", chip: "good", uses: 5, slots: 1, kind: "Section" },
  { name: "product-grid · breakout", v: "v1.4", chip: "good", uses: 3, slots: 6, kind: "Grid" },
  { name: "service card · breakout", v: "v1.2", chip: "good", uses: 4, slots: 2, kind: "Card" },
  { name: "feature-strip · seasonal", v: "v0.9", chip: "warn", uses: 1, slots: 1, kind: "Strip" },
  { name: "testimonial reel", v: "v0.9", chip: "warn", uses: 1, slots: 3, kind: "Social" },
  { name: "cta-band · shop", v: "v1.1", chip: "good", uses: 3, slots: 0, kind: "CTA" },
  { name: "Hi-Tide Harry · assistant", v: "v0.4", chip: "shay", uses: 0, slots: 3, kind: "Interactive", active: true },
];

function ScreenComponentStudio() {
  const [tab, setTab] = React.useState("Preview");
  return (
    <div className="fade-up" style={{ height: "calc(100vh - 52px - 64px - 56px)", display: "grid", gridTemplateColumns: "260px 1fr 360px", gap: 14 }}>
      {/* Library */}
      <Card style={{ padding: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div className="p-3" style={{ borderBottom: "1px solid var(--hair)" }}>
          <div className="row between mb-3"><div className="h-section">Library</div><Tag>{COMP_LIB.length}</Tag></div>
          <div className="row gap-2">
            <input className="input" placeholder="Search before you create…" />
          </div>
          <div className="row gap-2 mt-2 fz-11" style={{ flexWrap: "wrap" }}>
            {["All","Hero","Section","Card","Strip","Interactive"].map((k, i) => <Chip key={k} tone={i === 0 ? "ember" : ""}>{k}</Chip>)}
          </div>
        </div>
        <div style={{ flex: 1, overflow: "auto", padding: 8 }}>
          {COMP_LIB.map((c, i) => (
            <div key={i} style={{ padding: "8px 10px", borderRadius: 8, border: c.active ? "1px solid oklch(0.78 0.14 65 / 0.4)" : "1px solid transparent", background: c.active ? "linear-gradient(180deg, oklch(0.78 0.14 65 / 0.06), transparent)" : "transparent", cursor: "pointer" }}>
              <div className="row between">
                <div className="row gap-2"><I name="cube" size={13} style={{ color: "var(--ink-3)" }} /><span className="fz-12 fw-500">{c.name}</span></div>
                <Chip tone={c.chip}>{c.chip === "good" ? "locked" : c.chip === "warn" ? "needs media" : "Shay"}</Chip>
              </div>
              <div className="row between mt-2 dim fz-11">
                <span className="mono">{c.v}</span>
                <span>{c.kind} · used {c.uses}×</span>
              </div>
            </div>
          ))}
        </div>
        <div className="p-3" style={{ borderTop: "1px solid var(--hair)" }}>
          <Btn icon="plus" kind="primary" style={{ width: "100%", justifyContent: "center" }}>New component</Btn>
          <div className="dim fz-11 mt-2">Shay searches the library first to avoid duplicates.</div>
        </div>
      </Card>

      {/* Workbench */}
      <Card style={{ padding: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div className="row between p-3" style={{ borderBottom: "1px solid var(--hair)" }}>
          <div className="row gap-3">
            <div style={{ width: 32, height: 32, borderRadius: 8, background: "radial-gradient(circle at 30% 25%, oklch(0.78 0.14 65), oklch(0.42 0.18 30))", display: "grid", placeItems: "center", color: "oklch(0.16 0.04 60)" }}><I name="cube" size={16} /></div>
            <div>
              <div className="row gap-2"><span className="fw-500 fz-13">Hi-Tide Harry · Assistant</span><Tag>v0.4</Tag><Chip tone="shay">Shay reviewing</Chip></div>
              <div className="dim fz-11">Interactive · 3 slots · 4 variants · used 0× (ready to insert)</div>
            </div>
          </div>
          <div className="row gap-2">
            <Btn kind="ghost" icon="copy">Duplicate</Btn>
            <Btn icon="arrowUpRight">Insert into site / slot</Btn>
            <Btn icon="check" kind="primary">Promote v0.4 → locked</Btn>
          </div>
        </div>

        <div className="row between p-3" style={{ borderBottom: "1px solid var(--hair)" }}>
          <Tabs items={["Preview","Props / slots","Variants","Test states","History"]} value={tab} onChange={setTab} />
          <div className="seg">
            <button className="on"><I name="monitor" size={12} /></button>
            <button><I name="phone" size={12} /></button>
          </div>
        </div>

        <div style={{ flex: 1, overflow: "auto", padding: 16, background: "radial-gradient(60% 40% at 30% 0%, oklch(0.18 0.013 265 / 0.6), transparent 70%)" }}>
          {/* Big preview of Hi-Tide Harry assistant */}
          <div style={{ maxWidth: 720, margin: "0 auto" }}>
            <Card hi style={{ padding: 0, overflow: "hidden", boxShadow: "var(--shadow-2)" }}>
              <MediaTile seed={2} ratio="16 / 7" label="Coastal hardware · low tide haze" />
              <div className="p-4" style={{ display: "grid", gridTemplateColumns: "60px 1fr auto", gap: 14, alignItems: "flex-start" }}>
                <div style={{ width: 60, height: 60, borderRadius: 16, background: "linear-gradient(135deg, oklch(0.62 0.14 200), oklch(0.40 0.18 230))", display: "grid", placeItems: "center", color: "oklch(0.95 0.02 240)", fontFamily: "var(--font-serif)", fontSize: 28 }}>H</div>
                <div>
                  <div className="serif" style={{ fontSize: 22, color: "var(--ink)" }}>Hey, I'm Harry.</div>
                  <div className="muted fz-12 mt-2">Tell me what you're working on — fence post, dock board, the one bolt that always rusts. I'll point you at the right shelf.</div>
                  <div className="row gap-2 mt-3" style={{ flexWrap: "wrap" }}>
                    {["Tide tonight","Fasteners for salt","Marine grade lumber","Ask about an order"].map(s => <Chip key={s}>{s}</Chip>)}
                  </div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div className="fz-11 dim">Tide · Wilmington</div>
                  <div className="serif" style={{ fontSize: 22, color: "var(--ember)" }}>2.4 ft</div>
                  <div className="dim fz-11">low @ 6:18p</div>
                </div>
              </div>
              <div className="p-4" style={{ borderTop: "1px solid var(--hair)", display: "flex", gap: 8 }}>
                <input className="input" placeholder="Ask Harry…" />
                <Btn icon="send" kind="primary" />
              </div>
            </Card>

            {/* test states row */}
            <div className="mt-6">
              <Eyebrow>Test states</Eyebrow>
              <div className="row gap-2 mt-2" style={{ flexWrap: "wrap" }}>
                {[
                  { name: "Empty", chip: "good" },
                  { name: "Loading", chip: "good" },
                  { name: "Error · network", chip: "warn" },
                  { name: "Filled · long answer", chip: "good" },
                  { name: "Hover", chip: "good" },
                  { name: "No tide data", chip: "warn" },
                ].map(s => (
                  <div key={s.name} className="row gap-2" style={{ padding: "6px 10px", borderRadius: 8, border: "1px solid var(--hair)", fontSize: 11 }}>
                    <Dot tone={s.chip} /><span>{s.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Right inspector — props/slots/history */}
      <Card style={{ padding: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div className="p-3" style={{ borderBottom: "1px solid var(--hair)" }}>
          <div className="row between"><div className="h-section">Inspector</div><Btn kind="ghost" icon="more" /></div>
        </div>
        <div className="p-3" style={{ flex: 1, overflow: "auto" }}>
          <Field label="Slots">
            <div className="col gap-2">
              <Slot filled><Tag>hero-bg</Tag><span className="dim fz-11" style={{ marginLeft: "auto" }}>coastal-haze-02</span></Slot>
              <Slot filled><Tag>character</Tag><span className="dim fz-11" style={{ marginLeft: "auto" }}>harry-portrait-v3</span></Slot>
              <Slot><Tag>context-card</Tag><span className="dim fz-11" style={{ marginLeft: "auto" }}>not yet bound</span></Slot>
            </div>
          </Field>

          <div className="mt-4">
            <Field label="Props">
              <div className="col gap-2">
                {[
                  { k: "tone", v: "warm-coastal" },
                  { k: "showTide", v: "true" },
                  { k: "fallbackResponses", v: "5 prepared" },
                  { k: "openOnLoad", v: "false" },
                ].map(p => (
                  <div key={p.k} className="row between fz-12" style={{ padding: "6px 10px", borderRadius: 6, border: "1px solid var(--hair)" }}>
                    <span className="mono dim">{p.k}</span><span className="mono" style={{ color: "var(--ink-2)" }}>{p.v}</span>
                  </div>
                ))}
              </div>
            </Field>
          </div>

          <div className="mt-4">
            <Field label="Variants">
              <div className="row gap-2" style={{ flexWrap: "wrap" }}>
                {["coastal","mountain","desert","city"].map((v, i) => (
                  <div key={v} style={{ width: 56 }}>
                    <MediaTile seed={i + 4} ratio="1 / 1" />
                    <div className="dim fz-11 mt-2" style={{ textAlign: "center" }}>{v}</div>
                  </div>
                ))}
              </div>
            </Field>
          </div>

          <div className="mt-4">
            <Field label="Mutation history">
              <div className="col gap-2 fz-11">
                {[
                  { v: "v0.4", note: "added tide context card · Shay", t: "5m" },
                  { v: "v0.3", note: "warmer hover state", t: "1h" },
                  { v: "v0.2", note: "extracted from Hi-Tide Harry site", t: "1d" },
                  { v: "v0.1", note: "first sketch", t: "3d" },
                ].map((h, i) => (
                  <div key={i} className="row gap-3" style={{ padding: "6px 0" }}>
                    <Tag tone="ember">{h.v}</Tag>
                    <span className="muted grow">{h.note}</span>
                    <span className="dim mono">{h.t}</span>
                  </div>
                ))}
              </div>
            </Field>
          </div>
        </div>
        <div className="p-3" style={{ borderTop: "1px solid var(--hair)" }}>
          <div className="h-section mb-3">Insert into</div>
          <div className="col gap-2">
            <div className="row between" style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--hair)" }}>
              <div className="row gap-2"><I name="sites" size={13} /><span className="fz-12">Hi-Tide Harry</span><Tag>/help</Tag></div>
              <Btn>Insert</Btn>
            </div>
            <div className="row between" style={{ padding: "8px 10px", borderRadius: 8, border: "1px dashed var(--hair-2)" }}>
              <div className="row gap-2"><I name="layers" size={13} /><span className="fz-12 dim">Pick another site / slot…</span></div>
              <Btn kind="ghost" icon="search" />
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}

window.ScreenComponentStudio = ScreenComponentStudio;
