/* Sites Dashboard */

const SITES = [
  { name: "The Best Lawn Care", niche: "Home services · Atlanta", status: "live", url: "the-best-lawn-care.netlify.app", deploy: "Live", chip: "good", pages: 7, updated: "2d", media: 24, comps: 6, seed: 3 },
  { name: "Auntie Gale", niche: "Local artisan goods · Asheville", status: "build", url: "preview.auntie-gale.fam", deploy: "Draft", chip: "warn", pages: 5, updated: "12m", media: 18, comps: 4, seed: 5, blocked: 2 },
  { name: "Hi-Tide Harry", niche: "Coastal hardware · Wilmington", status: "design", url: "preview.hi-tide.fam", deploy: "—", chip: "", pages: 3, updated: "1h", media: 6, comps: 2, seed: 7 },
  { name: "Groove Theory", niche: "Music studio · Detroit", status: "live", url: "groovetheory.studio", deploy: "Live", chip: "good", pages: 9, updated: "1w", media: 31, comps: 8, seed: 9 },
  { name: "Down The Block", niche: "Neighborhood news · Brooklyn", status: "build", url: "preview.dtb.fam", deploy: "Draft", chip: "warn", pages: 6, updated: "3h", media: 14, comps: 5, seed: 11 },
  { name: "Foster's Forge", niche: "Custom metalwork · Pittsburgh", status: "research", url: "—", deploy: "—", chip: "", pages: 0, updated: "2d", media: 0, comps: 0, seed: 13 },
];

function ScreenSites() {
  const [view, setView] = React.useState("Grid");
  const [filter, setFilter] = React.useState("All");

  return (
    <div className="fade-up">
      <SectionHeader
        eyebrow="Sites · 6 active · 2 live"
        title="Your sites"
        sub="Every site is a portfolio piece. Open one to enter its build workspace, or start something new."
        right={
          <>
            <div className="seg">
              {["All","Live","Building","Design","Research"].map(f => <button key={f} className={filter === f ? "on" : ""} onClick={() => setFilter(f)}>{f}</button>)}
            </div>
            <Seg items={["Grid","List"]} value={view} onChange={setView} />
            <Btn icon="plus" kind="primary">New site</Btn>
          </>
        }
      />

      {/* New + Continue strip */}
      <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr 1fr", gap: 12, marginBottom: 18 }}>
        <Card hi style={{ background: "linear-gradient(135deg, oklch(0.20 0.014 265 / 0.7), oklch(0.14 0.012 265 / 0.7))", borderStyle: "dashed", borderColor: "oklch(0.78 0.14 65 / 0.3)" }}>
          <div className="row gap-3">
            <div style={{ width: 56, height: 56, borderRadius: 14, background: "radial-gradient(circle at 30% 25%, oklch(0.85 0.14 65), oklch(0.45 0.18 35))", display: "grid", placeItems: "center", color: "oklch(0.16 0.04 60)", boxShadow: "var(--shadow-glow)" }}>
              <I name="plus" size={24} />
            </div>
            <div className="grow">
              <div className="h-title">Start a new site</div>
              <div className="muted fz-12 mt-2">Describe the business and Shay assembles a template-first build plan. Brainstorm in Think-Tank first if you're still scoping.</div>
            </div>
          </div>
          <div className="row gap-2 mt-3">
            <Btn icon="spark" kind="primary">From description</Btn>
            <Btn icon="brain">Start in Think-Tank</Btn>
            <Btn icon="upload">Import existing</Btn>
          </div>
        </Card>
        <Card>
          <Eyebrow>Continue where you left off</Eyebrow>
          <div className="h-title mt-2">Auntie Gale · /shop</div>
          <div className="muted fz-12 mt-2">86% — 2 image slots deferred, 1 component swap pending.</div>
          <Meter value={86} />
          <div className="row gap-2 mt-3">
            <Btn icon="play" kind="primary">Resume</Btn>
            <Btn>Inspect</Btn>
          </div>
        </Card>
        <Card>
          <Eyebrow>Quick links</Eyebrow>
          <div className="col gap-2 mt-2 fz-12">
            <a className="row between" style={{ color: "var(--ink-2)" }}><span><I name="globe" size={12} /> Deployments</span><span className="dim">2 live · 0 pending</span></a>
            <a className="row between" style={{ color: "var(--ink-2)" }}><span><I name="settings" size={12} /> Site defaults</span><span className="dim">platform-wide</span></a>
            <a className="row between" style={{ color: "var(--ink-2)" }}><span><I name="layers" size={12} /> Templates</span><span className="dim">4 saved</span></a>
            <a className="row between" style={{ color: "var(--ink-2)" }}><span><I name="trophy" size={12} /> SITE-LEARNINGS</span><span className="dim">31 captured</span></a>
          </div>
        </Card>
      </div>

      {/* Grid of sites */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
        {SITES.map((s, i) => (
          <Card key={i} hover style={{ padding: 0, overflow: "hidden" }}>
            <div style={{ position: "relative" }}>
              <MediaTile seed={s.seed} ratio="16 / 10" label={s.url} />
              <div style={{ position: "absolute", left: 10, top: 10 }}>
                <Chip tone={s.chip}>{s.deploy}</Chip>
              </div>
              {s.blocked ? (
                <div style={{ position: "absolute", right: 10, top: 10 }}>
                  <Chip tone="warn">{s.blocked} blocking</Chip>
                </div>
              ) : null}
              <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: "20px 14px 12px", background: "linear-gradient(180deg, transparent, oklch(0.10 0.010 265 / 0.85))" }}>
                <div className="fw-500 fz-14">{s.name}</div>
                <div className="dim fz-11">{s.niche}</div>
              </div>
            </div>
            <div className="p-3" style={{ borderTop: "1px solid var(--hair)" }}>
              <div className="row gap-3 fz-11 muted" style={{ marginBottom: 8 }}>
                <span><I name="doc" size={11} /> {s.pages} pages</span>
                <span><I name="media" size={11} /> {s.media}</span>
                <span><I name="cube" size={11} /> {s.comps}</span>
                <span style={{ marginLeft: "auto" }} className="mono dim tabular">{s.updated} ago</span>
              </div>
              <div className="row gap-2">
                <Btn kind="ghost" icon="eye">Preview</Btn>
                <Btn kind="ghost" icon="settings">Settings</Btn>
                <Btn icon="arrowRight" style={{ marginLeft: "auto" }}>Open</Btn>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

window.ScreenSites = ScreenSites;
