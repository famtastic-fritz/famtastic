/* Site Settings — two-level: platform defaults + local current-site */

function ScreenSiteSettings() {
  const [scope, setScope] = React.useState("This site");

  return (
    <div className="fade-up">
      <SectionHeader
        eyebrow="Site settings"
        title="Auntie Gale"
        sub="Two scopes: settings for this site override the platform defaults. Toggle scope to compare."
        right={
          <Seg items={["Platform defaults","This site"]} value={scope} onChange={setScope} />
        }
      />

      {scope === "This site" ? (
        <div className="row gap-2 mb-4">
          <Chip tone="ember">5 overrides active</Chip>
          <Chip>Resets reset to platform default</Chip>
          <Btn kind="ghost" icon="diff">Show diff vs platform</Btn>
        </div>
      ) : (
        <div className="row gap-2 mb-4">
          <Chip>Applied to all new sites</Chip>
          <Chip tone="aurora">Existing sites inherit on next build</Chip>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
        {/* Identity */}
        <Card>
          <div className="h-section mb-3">Identity</div>
          <div className="col gap-3">
            <Field label="Site name"><input className="input" defaultValue="Auntie Gale" /></Field>
            <Field label="Tag" sub={<span className="mono">used in /sites/&lt;tag&gt;/</span>}>
              <input className="input" defaultValue="auntie-gale" />
            </Field>
            <Field label="Niche">
              <div className="row gap-2">
                <input className="input" defaultValue="Local artisan goods" />
                <Btn>Re-classify</Btn>
              </div>
            </Field>
            <Field label="Voice"><input className="input" defaultValue="Warm Sunday-market — earnest, plain-spoken." /></Field>
          </div>
        </Card>

        {/* Build behavior */}
        <Card>
          <div className="h-section mb-3">Build behavior</div>
          <div className="col gap-3">
            <Field label="Build mode" sub="Template-first is locked for nav consistency">
              <Seg items={["Template-first","Page-by-page"]} value="Template-first" onChange={() => {}} />
            </Field>
            <Field label="Hero vocabulary"><Tag tone="ember">fam-hero-layered v2.1</Tag></Field>
            <Field label="Section divider">
              <div className="row gap-2">
                {["wave","tilt","peak","arch"].map((d, i) => (
                  <div key={d} style={{ padding: "10px 12px", border: i === 2 ? "1px solid var(--ember)" : "1px solid var(--hair)", borderRadius: 8, fontSize: 11, cursor: "pointer", color: i === 2 ? "var(--ember)" : "var(--ink-3)" }}>
                    {d}
                  </div>
                ))}
              </div>
            </Field>
            <Field label="Above-the-fold rule" sub="from .brain/patterns.md">
              <div className="row between fz-12 muted"><span>hero breakout 100vw with negative margin</span><Toggle on={true} /></div>
            </Field>
          </div>
        </Card>

        {/* Media defaults */}
        <Card>
          <div className="h-section mb-3">Media defaults</div>
          <div className="col gap-3">
            <Field label="Provider chain" sub="failover order">
              <div className="row gap-2 mono fz-11">
                <Tag>Firefly</Tag>
                <I name="arrowRight" size={11} />
                <Tag>Unsplash</Tag>
                <I name="arrowRight" size={11} />
                <Tag>Pexels</Tag>
                <I name="arrowRight" size={11} />
                <Tag>Pixabay</Tag>
              </div>
            </Field>
            <Field label="Default style"><input className="input" defaultValue="Editorial · warm light · 35mm grain" /></Field>
            <Field label="Slot identity"><div className="row between fz-12 muted"><span>data-slot-id required (locked)</span><Chip tone="good">on</Chip></div></Field>
            <Field label="Auto-fill missing slots" sub="contextual queries: business + niche + role">
              <Toggle on={true} />
            </Field>
          </div>
        </Card>

        {/* Component defaults */}
        <Card>
          <div className="h-section mb-3">Component defaults</div>
          <div className="col gap-3">
            <Field label="Library">
              <div className="row gap-2"><Chip tone="aurora">FAM Core 14</Chip><Chip>Site-only 3</Chip></div>
            </Field>
            <Field label="Reuse policy">
              <Seg items={["Search first","Always create"]} value="Search first" onChange={() => {}} />
            </Field>
            <Field label="Test states required" sub="components must declare these">
              <div className="row gap-2 fz-11" style={{ flexWrap: "wrap" }}>
                {["empty","loading","error","filled","hover","focus"].map(s => <Chip key={s}>{s}</Chip>)}
              </div>
            </Field>
          </div>
        </Card>

        {/* Models / cost */}
        <Card>
          <div className="h-section mb-3">Models &amp; cost</div>
          <div className="col gap-3">
            <Field label="Builder model"><Seg items={["sonnet-4.5","opus-4.5","local"]} value="sonnet-4.5" onChange={() => {}} /></Field>
            <Field label="Operator readback model"><Seg items={["haiku-4.5","sonnet-4.5"]} value="haiku-4.5" onChange={() => {}} /></Field>
            <Field label="Cost cap (per build)" sub="approval required above"><input className="input mono tabular" defaultValue="$5.00" /></Field>
            <Field label="Approve under"><input className="input mono tabular" defaultValue="$0.50" /></Field>
          </div>
        </Card>

        {/* Deployment */}
        <Card>
          <div className="h-section mb-3">Deployment</div>
          <div className="col gap-3">
            <Field label="Target"><Seg items={["Netlify","Vercel","S3","Manual"]} value="Netlify" onChange={() => {}} /></Field>
            <Field label="Subdomain"><input className="input mono" defaultValue="auntie-gale.netlify.app" /></Field>
            <Field label="Custom domain"><div className="row gap-2"><input className="input mono" defaultValue="auntiegale.shop" /><Chip tone="warn">DNS pending</Chip></div></Field>
            <Field label="Auto-publish on" sub="all 5 file checks must pass">
              <Toggle on={false} label="off — Shay asks first" />
            </Field>
          </div>
        </Card>
      </div>
    </div>
  );
}

window.ScreenSiteSettings = ScreenSiteSettings;
