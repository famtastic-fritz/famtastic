/* App entry — wires everything together */

const SCREENS = {
  home:       { title: "Platform Home",     comp: () => <ScreenHome /> },
  sites:      { title: "Sites",             comp: () => <ScreenSites /> },
  builder:    { title: "Site Builder",      comp: () => <ScreenSiteBuilder /> },
  siteset:    { title: "Site Settings",     comp: () => <ScreenSiteSettings /> },
  thinktank:  { title: "Think-Tank",        comp: () => <ScreenThinkTank /> },
  research:   { title: "Research Center",   comp: () => <ScreenResearch /> },
  components: { title: "Component Studio",  comp: () => <ScreenComponentStudio /> },
  media:      { title: "Media Studio",      comp: () => <ScreenMediaStudio /> },
  library:    { title: "Media Library",     comp: () => <ScreenMediaLibrary /> },
  shay:       { title: "Shay",              comp: () => <ScreenShay /> },
  mission:    { title: "Mission Control",   comp: () => <ScreenMissionControl /> },
  settings:   { title: "Settings",          comp: () => <ScreenSettings /> },
};

/* sites have a "section" treatment — clicking Sites in rail shows dashboard,
   but inside we let the user jump to builder/settings via subtabs */
function App() {
  const [section, setSection] = React.useState("home");
  const [sub, setSub] = React.useState(null);
  const [bubbleOpen, setBubbleOpen] = React.useState(false);

  // Map rail section → screen key
  const screenKey = (() => {
    if (section === "sites") return sub || "sites";
    if (section === "media") return sub || "media";
    return section;
  })();
  const Screen = SCREENS[screenKey]?.comp;

  // Default site/project shown in topbar
  const project = "FAMtastic";
  const site = section === "sites" || section === "home" || screenKey === "builder" || screenKey === "siteset" ? "Auntie Gale" : "—";

  // Optional sub-tab bar inside Sites + Media
  const subtabs = (() => {
    if (section === "sites") return ["sites","builder","siteset"].map(k => ({ k, label: { sites: "Dashboard", builder: "Builder", siteset: "Settings" }[k] }));
    if (section === "media") return ["media","library"].map(k => ({ k, label: { media: "Studio", library: "Library" }[k] }));
    return null;
  })();

  // route data overrides for builder/library default
  React.useEffect(() => {
    setSub(null);
  }, [section]);

  return (
    <div className="app" data-section={screenKey} data-screen-label={SCREENS[screenKey]?.title}>
      <Rail active={section} onSelect={setSection} />
      <div className="shell">
        <Topbar section={screenKey} project={project} site={site} />

        {subtabs ? (
          <div style={{ borderBottom: "1px solid var(--hair)", padding: "0 18px", display: "flex", alignItems: "center", gap: 4, background: "oklch(0.10 0.010 265 / 0.5)", height: 36 }}>
            {subtabs.map(t => (
              <div key={t.k}
                   onClick={() => setSub(t.k)}
                   style={{ padding: "6px 12px", fontSize: 12, color: screenKey === t.k ? "var(--ember)" : "var(--ink-3)", borderBottom: screenKey === t.k ? "1px solid var(--ember)" : "1px solid transparent", cursor: "pointer", marginBottom: -1 }}>
                {t.label}
              </div>
            ))}
            <div style={{ marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" }} className="dim fz-11">
              <span>{section === "sites" ? "Active site:" : "Active workspace:"}</span>
              <Tag tone="ember">{section === "sites" ? "auntie-gale" : section}</Tag>
            </div>
          </div>
        ) : null}

        <div className={`body ${["builder","components","media","shay"].includes(screenKey) ? "no-right" : ""}`}>
          <main className="workspace">
            {Screen ? <Screen /> : <div className="muted">Coming soon.</div>}
          </main>
          {!["builder","components","media","shay"].includes(screenKey) ? <ContextPanel section={screenKey} /> : null}
        </div>

        <MemoryStrip />
      </div>

      <ShayBubble onClick={() => { setSection("shay"); setBubbleOpen(true); }} />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
