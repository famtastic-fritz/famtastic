/* Platform Home — command center */

function ScreenHome() {
  return (
    <div className="fade-up">
      <div className="row between" style={{ marginBottom: 22 }}>
        <div>
          <Eyebrow>Wednesday · May 13</Eyebrow>
          <div className="h-display mt-2" style={{ fontSize: 36 }}>
            Good evening, Fritz. <span className="serif" style={{ color: "var(--ember)", fontStyle: "italic" }}>Three things</span> are waiting.
          </div>
          <div className="aurora-line mt-3" style={{ width: 220 }} />
        </div>
        <div className="row gap-2">
          <Btn icon="plus">New site</Btn>
          <Btn icon="spark" kind="primary">New build</Btn>
        </div>
      </div>

      {/* hero command row — 3 next-actions */}
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr", gap: 14, marginBottom: 22 }}>
        <Card hi style={{ position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", inset: -1, background: "radial-gradient(50% 80% at 0% 0%, oklch(0.78 0.14 65 / 0.12), transparent 60%)", pointerEvents: "none" }} />
          <div className="row between mb-3">
            <Eyebrow>Most likely next</Eyebrow>
            <Chip tone="ember">Recommended</Chip>
          </div>
          <div className="h-title">Continue <i className="serif">Auntie Gale</i> — finish /shop</div>
          <div className="muted fz-12 mt-2">Template-first build is 86% complete. Two deferred images and one component slot remain. Estimated 6 minutes.</div>
          <div className="row gap-2 mt-3">
            <span className="fz-11"><Meter value={86} /></span>
          </div>
          <div className="row between mt-4">
            <div className="row gap-2 fz-11 dim">
              <Tag>site-auntie-gale</Tag>
              <Tag>rn-92a</Tag>
              <span className="mono tabular">$2.40 spent · est. $0.18 to finish</span>
            </div>
            <div className="row gap-2">
              <Btn>Inspect</Btn>
              <Btn icon="play" kind="primary">Resume</Btn>
            </div>
          </div>
        </Card>

        <Card>
          <Eyebrow>Pending approval</Eyebrow>
          <div className="h-title mt-2">6 image variants — "amber dusk lawn"</div>
          <div className="row gap-2 mt-3" style={{ overflow: "hidden" }}>
            {[0,1,2,3].map(i => <MediaTile key={i} seed={i + 9} ratio="1 / 1" style={{ width: 56 }} />)}
            <div className="media-tile" style={{ width: 56, aspectRatio: "1 / 1", background: "transparent", borderStyle: "dashed", color: "var(--ink-3)", fontSize: 11 }}>+2</div>
          </div>
          <div className="row gap-2 mt-3">
            <Btn icon="check">Review</Btn>
            <span className="dim fz-11 mono tabular">$0.36 · Firefly</span>
          </div>
        </Card>

        <Card>
          <Eyebrow>Worth your attention</Eyebrow>
          <div className="h-title mt-2">Research brief: <i className="serif">home services local SEO</i></div>
          <div className="muted fz-12 mt-2">Shay flagged 3 opportunities for the Lawn Care site that map to current rankings.</div>
          <div className="row gap-2 mt-3">
            <Chip tone="aurora">3 opportunities</Chip>
            <Chip>9 sources</Chip>
          </div>
          <div className="row gap-2 mt-3">
            <Btn>Open brief</Btn>
            <Btn kind="ghost" icon="arrowRight">Promote to site task</Btn>
          </div>
        </Card>
      </div>

      {/* main grid */}
      <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 14 }}>
        <div className="col gap-3">
          {/* Recent sites */}
          <Card>
            <div className="between mb-3">
              <div>
                <div className="h-section">Recent sites</div>
              </div>
              <Btn kind="ghost" icon="arrowRight">All sites</Btn>
            </div>
            <div className="col gap-2">
              {[
                { name: "Auntie Gale", niche: "Local artisan goods", status: "build", pct: 86, deploy: "draft", chip: "warn" },
                { name: "The Best Lawn Care", niche: "Home services", status: "live", pct: 100, deploy: "live", chip: "good" },
                { name: "Hi-Tide Harry", niche: "Coastal hardware", status: "design", pct: 42, deploy: "—", chip: "" },
                { name: "Groove Theory", niche: "Music studio", status: "live", pct: 100, deploy: "live", chip: "good" },
              ].map((s, i) => (
                <div key={i} className="row gap-3" style={{ padding: "10px 12px", borderRadius: 10, border: "1px solid var(--hair)", background: "oklch(0.13 0.012 265 / 0.4)" }}>
                  <MediaTile seed={i + 3} ratio="4 / 3" style={{ width: 64 }} label={s.name.slice(0,3).toUpperCase()} />
                  <div className="grow">
                    <div className="row between">
                      <div className="fw-500 fz-13">{s.name}</div>
                      <div className="row gap-2">
                        <Chip tone={s.chip}>{s.deploy}</Chip>
                        <span className="dim fz-11 mono tabular">{s.pct}%</span>
                      </div>
                    </div>
                    <div className="muted fz-11 mt-2">{s.niche} · {s.status}</div>
                    <div className="mt-2"><Meter value={s.pct} tone={s.pct === 100 ? "good" : ""} /></div>
                  </div>
                  <div className="row gap-2">
                    <Btn kind="ghost" icon="eye">Preview</Btn>
                    <Btn>Continue</Btn>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Recent media */}
          <Card>
            <div className="between mb-3">
              <div className="h-section">Recent media</div>
              <Btn kind="ghost" icon="arrowRight">Library</Btn>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(8, 1fr)", gap: 8 }}>
              {[...Array(16)].map((_, i) => (
                <MediaTile key={i} seed={i + 21} ratio="1 / 1"
                  badge={i % 5 === 0 ? <Chip tone="good" style={{ fontSize: 9, padding: "1px 5px" }}>✓</Chip> : i % 7 === 0 ? <Chip tone="warn" style={{ fontSize: 9, padding: "1px 5px" }}>?</Chip> : null}
                />
              ))}
            </div>
          </Card>
        </div>

        <div className="col gap-3">
          {/* Recent components */}
          <Card>
            <div className="between mb-3">
              <div className="h-section">Recent components</div>
              <Btn kind="ghost" icon="arrowRight">Studio</Btn>
            </div>
            <div className="col gap-2">
              {[
                { name: "Hi-Tide Harry · Assistant", v: "v0.4", slots: "3 slots · 4 variants", chip: "shay", chipText: "Shay reviewing" },
                { name: "fam-hero-layered", v: "v2.1", slots: "4 layers · 6 variants", chip: "good", chipText: "Locked" },
                { name: "Service card · breakout", v: "v1.2", slots: "2 slots · 3 variants", chip: "", chipText: "Used in 2 sites" },
                { name: "Testimonial reel", v: "v0.9", slots: "1 slot · 2 variants", chip: "warn", chipText: "Needs media" },
              ].map((c, i) => (
                <div key={i} className="row gap-3" style={{ padding: "10px 12px", borderRadius: 10, border: "1px solid var(--hair)" }}>
                  <div style={{ width: 36, height: 36, borderRadius: 8, background: "linear-gradient(135deg, var(--panel-3), var(--panel))", border: "1px solid var(--hair)", display: "grid", placeItems: "center", color: "var(--ink-3)" }}>
                    <I name="cube" size={16} />
                  </div>
                  <div className="grow">
                    <div className="fw-500 fz-12">{c.name} <span className="mono dim">{c.v}</span></div>
                    <div className="muted fz-11">{c.slots}</div>
                  </div>
                  <Chip tone={c.chip}>{c.chipText}</Chip>
                </div>
              ))}
            </div>
          </Card>

          {/* Active runs */}
          <Card>
            <div className="between mb-3">
              <div className="h-section">Active runs</div>
              <Btn kind="ghost" icon="arrowRight">Mission Control</Btn>
            </div>
            <div className="col gap-2">
              {[
                { id: "rn-92a", title: "Auntie Gale · /shop regen", pct: 86, eta: "6m", state: "running" },
                { id: "rn-93b", title: "Hi-Tide Harry · component test pass", pct: 32, eta: "11m", state: "running" },
                { id: "rn-94c", title: "Lawn Care · weekly intelligence brief", pct: 0, eta: "queued", state: "queued" },
              ].map((r, i) => (
                <div key={i} style={{ padding: "10px 12px", borderRadius: 10, border: "1px solid var(--hair)" }}>
                  <div className="row between">
                    <div className="row gap-2">
                      {r.state === "running" ? <Dot tone="good" /> : <Dot />}
                      <span className="fw-500 fz-12">{r.title}</span>
                    </div>
                    <Tag>{r.id}</Tag>
                  </div>
                  <div className="row gap-3 mt-2">
                    <div className="grow"><Meter value={r.pct} /></div>
                    <span className="mono dim fz-11 tabular">{r.eta}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Research briefs / system signal */}
          <Card>
            <div className="between mb-3">
              <div className="h-section">Signal</div>
              <Chip tone="aurora">Quiet day</Chip>
            </div>
            <div className="col gap-2 fz-12">
              <div className="row between"><span className="muted">Component reuse</span><span><b>3.2×</b> <span className="dim">vs solo build</span></span></div>
              <div className="row between"><span className="muted">First-paint avg</span><span><b>0.9s</b> <span className="dim">on shipped sites</span></span></div>
              <div className="row between"><span className="muted">Deferred images</span><span style={{ color: "var(--warn)" }}><b>2</b> blocking publish</span></div>
              <div className="row between"><span className="muted">Cost ÷ shipped page</span><span className="mono tabular"><b>$0.41</b></span></div>
            </div>
          </Card>
        </div>
      </div>

      {/* flow diagram of how the platform connects */}
      <Card hi className="mt-6" style={{ position: "relative", overflow: "hidden" }}>
        <div className="between mb-3">
          <div>
            <Eyebrow>How the work flows</Eyebrow>
            <div className="h-title mt-2">Research → Media → Library → Components → Sites · Shay across all</div>
          </div>
          <Btn kind="ghost" icon="arrowUpRight">Open as map</Btn>
        </div>
        <div style={{ position: "relative", height: 130 }}>
          <svg viewBox="0 0 900 130" preserveAspectRatio="none" style={{ width: "100%", height: "100%" }}>
            <defs>
              <linearGradient id="flowG" x1="0" x2="1">
                <stop offset="0" stopColor="oklch(0.74 0.13 200 / 0.5)" />
                <stop offset="1" stopColor="oklch(0.78 0.14 65 / 0.7)" />
              </linearGradient>
            </defs>
            <path d="M 60 65 C 200 65 220 65 360 65 S 540 65 720 65 L 840 65"
                  stroke="url(#flowG)" strokeWidth="1.3" fill="none" />
            <path d="M 60 95 C 250 105 480 30 840 65"
                  stroke="oklch(0.82 0.12 90 / 0.45)" strokeWidth="1" strokeDasharray="3 4" fill="none" />
          </svg>
          {[
            { x: 60, label: "Research", icon: "research" },
            { x: 240, label: "Media Studio", icon: "media" },
            { x: 420, label: "Media Library", icon: "layers" },
            { x: 600, label: "Component Studio", icon: "components" },
            { x: 780, label: "Sites", icon: "sites" },
          ].map((n, i) => (
            <div key={i} style={{ position: "absolute", left: `${(n.x / 900) * 100}%`, top: 36, transform: "translateX(-50%)", display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, background: "linear-gradient(180deg, var(--panel-2), var(--panel))", border: "1px solid var(--hair-3)", display: "grid", placeItems: "center", color: "var(--ink-2)" }}>
                <I name={n.icon} size={18} />
              </div>
              <div className="fz-11 muted">{n.label}</div>
            </div>
          ))}
          <div style={{ position: "absolute", left: 12, bottom: 10, display: "flex", alignItems: "center", gap: 8 }}>
            <Avatar kind="shay" initials="S" />
            <div className="fz-11 dim"><i className="serif" style={{ color: "var(--shay)" }}>Shay</i> threads through every step</div>
          </div>
        </div>
      </Card>
    </div>
  );
}

window.ScreenHome = ScreenHome;
