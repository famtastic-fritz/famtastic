/* Think-Tank / Brainstorm */

function ScreenThinkTank() {
  const [tab, setTab] = React.useState("Board");

  const cols = [
    { name: "Capture", chip: "", items: [
      { t: "Auntie Gale could host a 'Sunday market' digest mailer", chip: "" },
      { t: "Hi-Tide Harry assistant should know tide tables", chip: "ember" },
      { t: "Reusable testimonial reel — autoplay on scroll only", chip: "" },
    ]},
    { name: "Concept", chip: "aurora", items: [
      { t: "'Coming out of darkness' onboarding for new sites", chip: "ember", note: "promote → Component task?" },
      { t: "Brief-to-build: a research card you can drag into Sites", chip: "" },
      { t: "Component reuse score visible at section level", chip: "" },
    ]},
    { name: "Promoted", chip: "good", items: [
      { t: "Operator readback as a global keyboard layer", chip: "good", note: "→ Mission Control task" },
      { t: "Slot-based image identity surfaces in inspector", chip: "good", note: "→ Site Builder task" },
    ]},
    { name: "Paused", chip: "", items: [
      { t: "AI-generated dividers — quality not there", chip: "" },
      { t: "Animated hero character (Lottie)", chip: "" },
    ]},
  ];

  return (
    <div className="fade-up">
      <SectionHeader
        eyebrow="Think-Tank · Brainstorm"
        title="Where ideas live before they're work."
        sub="Capture freely. Promote what earns its keep into Research, Sites, Components, or Media."
        right={
          <>
            <Tabs items={["Board","Stream","Mind-map"]} value={tab} onChange={setTab} />
            <Btn icon="plus" kind="primary">Capture idea</Btn>
          </>
        }
      />

      {/* capture row */}
      <Card style={{ marginBottom: 14, borderStyle: "dashed", borderColor: "var(--hair-2)" }}>
        <div className="row gap-2">
          <Avatar kind="shay" initials="S" />
          <input className="input" placeholder="What's on your mind? Start typing — Shay clusters and routes." />
          <Btn icon="bolt">Quick add</Btn>
          <Btn icon="link">Link source</Btn>
        </div>
        <div className="row gap-2 mt-3 dim fz-11" style={{ flexWrap: "wrap" }}>
          <span>Suggest:</span>
          {["For Auntie Gale", "For Hi-Tide Harry", "Component idea", "Site idea", "Research question"].map(s => (
            <button key={s} className="btn btn-ghost" style={{ fontSize: 11 }}>{s}</button>
          ))}
        </div>
      </Card>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 }}>
        {cols.map((col, ci) => (
          <Card key={ci} style={{ padding: 12 }}>
            <div className="between mb-3">
              <div className="row gap-2"><span className="h-section">{col.name}</span><Chip tone={col.chip}>{col.items.length}</Chip></div>
              <button className="btn btn-ghost btn-icon"><I name="plus" size={12} /></button>
            </div>
            <div className="col gap-2">
              {col.items.map((it, ii) => (
                <div key={ii} style={{ padding: 10, borderRadius: 8, border: "1px solid var(--hair)", background: "oklch(0.13 0.012 265 / 0.4)" }}>
                  <div className="fz-12" style={{ color: "var(--ink)", lineHeight: 1.4 }}>{it.t}</div>
                  {it.note ? <div className="dim fz-11 mt-2">{it.note}</div> : null}
                  <div className="row between mt-3">
                    <div className="row gap-2">
                      {it.chip ? <Chip tone={it.chip}>{it.chip === "good" ? "promoted" : "high"}</Chip> : <span className="dim fz-11">low signal</span>}
                    </div>
                    <div className="row gap-2">
                      <button className="btn btn-ghost btn-icon" title="Promote"><I name="arrowUpRight" size={12} /></button>
                      <button className="btn btn-ghost btn-icon"><I name="more" size={12} /></button>
                    </div>
                  </div>
                </div>
              ))}
              <div className="slot fz-11">+ Add card</div>
            </div>
          </Card>
        ))}
      </div>

      {/* Promote-to drawer */}
      <Card hi className="mt-6">
        <div className="row between mb-3">
          <Eyebrow>Promote idea</Eyebrow>
          <Tag>card-1284 · "Operator readback as a global keyboard layer"</Tag>
        </div>
        <div className="row gap-2" style={{ flexWrap: "wrap" }}>
          {[
            { name: "Research question", icon: "research", note: "Frame as 'is keyboard-first faster?'" },
            { name: "Site task", icon: "sites", note: "Add to next site build" },
            { name: "Component", icon: "components", note: "Build operator-readback layer" },
            { name: "Media task", icon: "media", note: "Generate cover for the spec doc" },
            { name: "Mission run", icon: "mission", note: "Schedule a measured trial" },
          ].map((p, i) => (
            <Card key={i} hover style={{ minWidth: 200, flex: 1, background: "oklch(0.16 0.012 265 / 0.7)" }}>
              <div className="row gap-2"><div style={{ width: 28, height: 28, borderRadius: 8, border: "1px solid var(--hair-2)", display: "grid", placeItems: "center", color: "var(--ember)" }}><I name={p.icon} size={14} /></div><div className="fw-500 fz-12">{p.name}</div></div>
              <div className="dim fz-11 mt-2">{p.note}</div>
            </Card>
          ))}
        </div>
      </Card>
    </div>
  );
}

window.ScreenThinkTank = ScreenThinkTank;
