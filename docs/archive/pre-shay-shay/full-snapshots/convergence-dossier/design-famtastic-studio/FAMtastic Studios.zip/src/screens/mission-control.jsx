/* Mission Control — operator workspace */

function ScreenMissionControl() {
  return (
    <div className="fade-up">
      <SectionHeader
        eyebrow="Mission Control"
        title="The honest view of what's running."
        sub="Intelligence, ledger, capability truth, and proof. Important — but not loud."
        right={
          <>
            <Chip tone="good">All systems steady</Chip>
            <Btn kind="ghost" icon="refresh">Refresh</Btn>
            <Btn icon="zap" kind="primary">New run</Btn>
          </>
        }
      />

      {/* Top row — intelligence brief + capability truth + system status */}
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr", gap: 12, marginBottom: 14 }}>
        <Card hi style={{ position: "relative", overflow: "hidden" }}>
          <div className="bg-glow" />
          <div className="row between mb-3">
            <Eyebrow>Intelligence brief · today</Eyebrow>
            <Chip tone="aurora">3 signals</Chip>
          </div>
          <div className="col gap-3">
            {[
              { i: 1, t: "Lawn Care site rank held #4 for 'lawn care atlanta' (3 wks).", chip: "good" },
              { i: 2, t: "Auntie Gale build cost projected $4.20 — within $5 cap.", chip: "" },
              { i: 3, t: "Firefly P50 latency drifted 18s → 27s. No action needed yet.", chip: "warn" },
            ].map(s => (
              <div key={s.i} className="row gap-3" style={{ padding: 10, borderRadius: 8, border: "1px solid var(--hair)", background: "oklch(0.13 0.012 265 / 0.5)" }}>
                <Tag>{String(s.i).padStart(2,"0")}</Tag>
                <span className="fz-12 grow" style={{ color: "var(--ink)" }}>{s.t}</span>
                <Chip tone={s.chip || ""}>{s.chip === "good" ? "good" : s.chip === "warn" ? "watch" : "neutral"}</Chip>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <div className="row between mb-3"><Eyebrow>Capability truth</Eyebrow><Chip tone="good">Honest mode</Chip></div>
          <div className="col gap-2 fz-12">
            {[
              { c: "Site builds (template-first)", s: "verified", n: "6 shipped" },
              { c: "Image gen (4 providers)", s: "verified", n: "Firefly primary" },
              { c: "Component reuse", s: "partial", n: "3 of 8 sites" },
              { c: "Operator readback", s: "verified", n: "4 modes" },
              { c: "A/B testing", s: "not yet", n: "planned Q3" },
              { c: "Auto-deploy on approval", s: "off", n: "Shay asks first" },
            ].map((r, i) => (
              <div key={i} className="row between" style={{ padding: "6px 0", borderBottom: i < 5 ? "1px dashed var(--hair)" : "none" }}>
                <span style={{ color: "var(--ink-2)" }}>{r.c}</span>
                <span className="row gap-2"><span className="dim">{r.n}</span><Chip tone={r.s === "verified" ? "good" : r.s === "partial" ? "warn" : ""}>{r.s}</Chip></span>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <div className="row between mb-3"><Eyebrow>System status</Eyebrow><Dot tone="good" /></div>
          <div className="col gap-2 fz-12">
            {[
              { s: "Hub server", v: "up · 4d 11h" },
              { s: "spawnClaude pool", v: "2 / 6 active" },
              { s: "WS connections", v: "1 client" },
              { s: "MCP server", v: "ready" },
              { s: "Drive sync", v: "synced 4m ago" },
              { s: "Disk · /sites", v: "6.2 GB / 200 GB" },
            ].map((r, i) => (
              <div key={i} className="row between"><span className="muted">{r.s}</span><span className="mono dim">{r.v}</span></div>
            ))}
          </div>
        </Card>
      </div>

      {/* Run ledger */}
      <Card style={{ marginBottom: 14 }}>
        <div className="between mb-3">
          <div className="h-section">Run ledger</div>
          <div className="row gap-2">
            <Seg items={["All","Running","Done","Failed","Approval"]} value="All" onChange={() => {}} />
            <Btn kind="ghost" icon="filter">Filter</Btn>
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "90px 1fr 100px 110px 100px 110px 80px", gap: 0, fontSize: 11 }}>
          <div className="dim" style={{ padding: "8px 12px", borderBottom: "1px solid var(--hair)" }}>Run</div>
          <div className="dim" style={{ padding: "8px 12px", borderBottom: "1px solid var(--hair)" }}>What</div>
          <div className="dim" style={{ padding: "8px 12px", borderBottom: "1px solid var(--hair)" }}>State</div>
          <div className="dim" style={{ padding: "8px 12px", borderBottom: "1px solid var(--hair)" }}>Progress</div>
          <div className="dim" style={{ padding: "8px 12px", borderBottom: "1px solid var(--hair)" }}>Cost</div>
          <div className="dim" style={{ padding: "8px 12px", borderBottom: "1px solid var(--hair)" }}>Approval</div>
          <div className="dim" style={{ padding: "8px 12px", borderBottom: "1px solid var(--hair)" }}>Proof</div>
          {[
            { id: "rn-92a", what: "Auntie Gale · /shop regen", st: "running", pct: 86, cost: "$2.40", appr: "auto", proof: 5 },
            { id: "rn-93b", what: "Hi-Tide · component test pass", st: "running", pct: 32, cost: "$0.04", appr: "auto", proof: 2 },
            { id: "rn-94c", what: "Lawn Care · weekly intel brief", st: "queued", pct: 0, cost: "—", appr: "auto", proof: 0 },
            { id: "rn-91d", what: "Auntie Gale · template emit", st: "done", pct: 100, cost: "$1.18", appr: "auto", proof: 8 },
            { id: "rn-91c", what: "Hi-Tide Harry assistant v0.4", st: "done", pct: 100, cost: "$0.30", appr: "Shay→OK", proof: 3 },
            { id: "rn-90f", what: "Custom domain DNS check · auntiegale.shop", st: "blocked", pct: 50, cost: "—", appr: "you", proof: 1 },
            { id: "rn-90e", what: "Firefly retry · seasonal-bundle", st: "failed", pct: 70, cost: "$0.06", appr: "—", proof: 1 },
          ].map((r, i) => (
            <React.Fragment key={i}>
              <div style={{ padding: "10px 12px", borderBottom: "1px solid var(--hair)" }}><Tag>{r.id}</Tag></div>
              <div style={{ padding: "10px 12px", borderBottom: "1px solid var(--hair)", color: "var(--ink-2)" }}>{r.what}</div>
              <div style={{ padding: "10px 12px", borderBottom: "1px solid var(--hair)" }}>
                <Chip tone={r.st === "done" ? "good" : r.st === "running" ? "ember" : r.st === "blocked" ? "warn" : r.st === "failed" ? "crit" : ""}>{r.st}</Chip>
              </div>
              <div style={{ padding: "10px 12px", borderBottom: "1px solid var(--hair)" }}><Meter value={r.pct} tone={r.st === "done" ? "good" : r.st === "failed" ? "warn" : ""} /></div>
              <div style={{ padding: "10px 12px", borderBottom: "1px solid var(--hair)" }} className="mono tabular dim">{r.cost}</div>
              <div style={{ padding: "10px 12px", borderBottom: "1px solid var(--hair)" }} className="dim">{r.appr}</div>
              <div style={{ padding: "10px 12px", borderBottom: "1px solid var(--hair)" }}>{r.proof ? <Chip>{r.proof}</Chip> : <span className="dim">—</span>}</div>
            </React.Fragment>
          ))}
        </div>
      </Card>

      {/* Bottom row — proof packet, blockers, visual flow, cost */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1.2fr", gap: 12 }}>
        <Card>
          <div className="row between mb-3"><Eyebrow>Proof packet · rn-92a</Eyebrow><Btn kind="ghost" icon="download" /></div>
          <div className="col gap-2 fz-11">
            {[
              { f: "01-template-emit.html", k: "html" },
              { f: "02-hero-bg-amber-dusk-04.png", k: "img" },
              { f: "03-verify-checks.json", k: "json" },
              { f: "04-shop-regen-diff.patch", k: "diff" },
              { f: "05-build-log.txt", k: "log" },
            ].map((p, i) => (
              <div key={i} className="row between" style={{ padding: "6px 8px", borderRadius: 6, border: "1px solid var(--hair)" }}>
                <div className="row gap-2"><I name="doc" size={12} /><span className="mono">{p.f}</span></div>
                <Tag>{p.k}</Tag>
              </div>
            ))}
          </div>
          <div className="muted fz-11 mt-3">Receipts for what actually happened. Shareable.</div>
        </Card>

        <Card>
          <div className="row between mb-3"><Eyebrow>Blockers · 1</Eyebrow><Chip tone="warn">action needed</Chip></div>
          <div className="col gap-2">
            <Card style={{ background: "oklch(0.16 0.04 80 / 0.18)", borderColor: "oklch(0.80 0.14 80 / 0.4)" }}>
              <div className="fw-500 fz-12">DNS for auntiegale.shop not propagated</div>
              <div className="muted fz-11 mt-2">Need CNAME → auntie-gale.netlify.app. You'll do this; I can't.</div>
              <div className="row gap-2 mt-3"><Btn>Open DNS docs</Btn><Btn kind="ghost">Snooze 24h</Btn></div>
            </Card>
            <div className="muted fz-11 mt-2">Non-blocking · 2</div>
            <div className="row between fz-11" style={{ padding: "6px 8px", borderRadius: 6, border: "1px solid var(--hair)" }}>
              <span>Firefly latency drift</span><span className="dim">watching</span>
            </div>
            <div className="row between fz-11" style={{ padding: "6px 8px", borderRadius: 6, border: "1px solid var(--hair)" }}>
              <span>3 components without test states</span><span className="dim">queue</span>
            </div>
          </div>
        </Card>

        <Card>
          <div className="row between mb-3"><Eyebrow>Visual flow · rn-92a</Eyebrow><span className="dim fz-11 mono">/shop regen</span></div>
          <div style={{ position: "relative", height: 160 }}>
            <svg viewBox="0 0 600 160" style={{ width: "100%", height: "100%" }}>
              <path d="M 30 80 L 130 80 L 230 80 L 330 80 L 430 80 L 530 80" stroke="var(--hair-3)" strokeDasharray="3 4" fill="none" />
              <path d="M 30 80 L 130 80 L 230 80 L 330 80 L 430 80" stroke="var(--ember)" strokeWidth="1.5" fill="none" filter="drop-shadow(0 0 4px var(--ember))" />
            </svg>
            {[
              { x: 30, label: "load", state: "done" },
              { x: 130, label: "media", state: "done" },
              { x: 230, label: "compose", state: "done" },
              { x: 330, label: "verify", state: "done" },
              { x: 430, label: "regen", state: "now" },
              { x: 530, label: "publish", state: "next" },
            ].map((n, i) => (
              <div key={i} style={{ position: "absolute", left: (n.x / 600) * 100 + "%", top: 60, transform: "translateX(-50%)", textAlign: "center" }}>
                <div style={{ width: 32, height: 32, borderRadius: 999, background: n.state === "done" ? "linear-gradient(180deg, oklch(0.78 0.14 65), oklch(0.55 0.18 50))" : n.state === "now" ? "oklch(0.20 0.014 265)" : "oklch(0.13 0.012 265)", border: n.state === "now" ? "1px solid var(--ember)" : "1px solid var(--hair-2)", display: "grid", placeItems: "center", color: n.state === "done" ? "oklch(0.18 0.04 60)" : "var(--ink-2)" }}>
                  {n.state === "done" ? <I name="check" size={14} /> : n.state === "now" ? <I name="spinner" size={14} /> : <span className="fz-11">{i + 1}</span>}
                </div>
                <div className="fz-11 mt-2 dim">{n.label}</div>
              </div>
            ))}
          </div>
          <div className="row between mt-3 fz-11"><span className="dim">step 5 / 6</span><span className="mono tabular">~2:40 left</span></div>
        </Card>
      </div>

      {/* cost / approval bar */}
      <Card hi className="mt-6">
        <div className="row between">
          <div className="row gap-3">
            <div style={{ width: 36, height: 36, borderRadius: 10, background: "linear-gradient(135deg, oklch(0.30 0.08 80), oklch(0.18 0.05 50))", display: "grid", placeItems: "center", color: "var(--ember)", border: "1px solid var(--hair-2)" }}><I name="bolt" size={16} /></div>
            <div>
              <div className="fw-500">Today's spend</div>
              <div className="dim fz-11">resets daily · cap $50 · Shay asks above $5/run</div>
            </div>
          </div>
          <div className="row gap-3" style={{ alignItems: "center" }}>
            <div style={{ width: 260 }}><Meter value={29} /></div>
            <div className="mono tabular"><b>$14.82</b><span className="dim"> / $50</span></div>
          </div>
        </div>
      </Card>
    </div>
  );
}

window.ScreenMissionControl = ScreenMissionControl;
