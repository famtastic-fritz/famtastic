/* Media Studio — text-to-image / asset generation */

function ScreenMediaStudio() {
  const [provider, setProvider] = React.useState("Firefly");
  const [ratio, setRatio] = React.useState("16:10");

  return (
    <div className="fade-up" style={{ height: "calc(100vh - 52px - 64px - 56px)", display: "grid", gridTemplateColumns: "320px 1fr 340px", gap: 14 }}>
      {/* Left: prompt */}
      <Card style={{ padding: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div className="p-3" style={{ borderBottom: "1px solid var(--hair)" }}>
          <div className="row between"><div className="h-section">Generate</div><Tag>session 14</Tag></div>
        </div>
        <div className="p-3" style={{ flex: 1, overflow: "auto" }}>
          <Field label="Prompt" sub="Shay can rewrite for the active provider">
            <textarea className="input" rows={5} defaultValue="Sunday market stall, amber dusk, hand-painted signage, soft 35mm grain, warm light spill, low contrast." style={{ resize: "vertical", lineHeight: 1.5 }} />
          </Field>
          <div className="row gap-2 mt-3 fz-11" style={{ flexWrap: "wrap" }}>
            <Chip tone="shay">+ market voice</Chip>
            <Chip tone="shay">+ low-key composition</Chip>
            <Chip>+ negative: harsh sun</Chip>
            <button className="btn btn-ghost" style={{ fontSize: 11 }}><I name="plus" size={11} /> add</button>
          </div>

          <div className="mt-4">
            <Field label="Reference">
              <div className="row gap-2">
                <MediaTile seed={6} ratio="1 / 1" style={{ width: 64 }} />
                <MediaTile seed={7} ratio="1 / 1" style={{ width: 64 }} />
                <div style={{ width: 64, height: 64, borderRadius: 8, border: "1px dashed var(--hair-2)", display: "grid", placeItems: "center", color: "var(--ink-3)" }}>
                  <I name="upload" size={16} />
                </div>
              </div>
            </Field>
          </div>

          <div className="mt-4">
            <Field label="Provider">
              <div className="seg">
                {["Firefly","Imagen","Mid-J","Local"].map(p => <button key={p} className={provider === p ? "on" : ""} onClick={() => setProvider(p)}>{p}</button>)}
              </div>
            </Field>
          </div>
          <div className="mt-3">
            <Field label="Aspect">
              <div className="seg">
                {["1:1","4:3","3:2","16:10","16:9","9:16"].map(r => <button key={r} className={ratio === r ? "on" : ""} onClick={() => setRatio(r)}>{r}</button>)}
              </div>
            </Field>
          </div>
          <div className="mt-3">
            <Field label="Variations" sub="6 default · est. $0.36"><Seg items={["2","4","6","8"]} value="6" onChange={() => {}} /></Field>
          </div>

          <div className="mt-4">
            <Field label="For slot" sub="optional — auto-tags result with data-slot-id">
              <div className="row gap-2">
                <Tag>shop-hero</Tag>
                <Tag>seasonal-bundle</Tag>
                <button className="btn btn-ghost" style={{ fontSize: 11 }}><I name="plus" size={11} /></button>
              </div>
            </Field>
          </div>
        </div>
        <div className="p-3" style={{ borderTop: "1px solid var(--hair)" }}>
          <div className="row between fz-11 dim mb-2"><span>Cost estimate</span><span className="mono tabular">~$0.36 · ~28s</span></div>
          <Btn icon="zap" kind="primary" style={{ width: "100%", justifyContent: "center" }}>Generate 6</Btn>
        </div>
      </Card>

      {/* Center: variations grid */}
      <Card style={{ padding: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div className="row between p-3" style={{ borderBottom: "1px solid var(--hair)" }}>
          <div className="row gap-3">
            <div className="h-title">Variations</div>
            <Chip tone="ember">6 new</Chip>
            <span className="dim fz-11 mono">amber-dusk-04 · {provider} · {ratio}</span>
          </div>
          <div className="row gap-2">
            <Btn kind="ghost" icon="diff">Compare</Btn>
            <Btn kind="ghost" icon="filter">Filter</Btn>
            <Btn icon="refresh">Re-roll</Btn>
          </div>
        </div>
        <div style={{ flex: 1, overflow: "auto", padding: 16 }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
            {[
              { seed: 4, status: "approved", chip: "good", tag: "approved · slot:shop-hero" },
              { seed: 14, status: "review", chip: "shay", tag: "Shay's pick" },
              { seed: 24, status: "review", chip: "" },
              { seed: 34, status: "rejected", chip: "crit", tag: "rejected · too dark" },
              { seed: 44, status: "review", chip: "" },
              { seed: 54, status: "review", chip: "" },
            ].map((v, i) => (
              <div key={i} style={{ position: "relative" }}>
                <MediaTile seed={v.seed} ratio={ratio === "1:1" ? "1/1" : ratio === "9:16" ? "9/16" : "16/10"} style={{ borderColor: v.chip === "good" ? "oklch(0.74 0.14 155 / 0.5)" : v.chip === "crit" ? "oklch(0.66 0.20 25 / 0.4)" : "var(--hair)" }} />
                <div className="row gap-2 mt-2 between">
                  <div className="row gap-2">
                    <Tag>v{i + 1}</Tag>
                    {v.chip ? <Chip tone={v.chip}>{v.tag || v.status}</Chip> : null}
                  </div>
                  <div className="row gap-2">
                    <button className="btn btn-ghost btn-icon" title="Approve"><I name="check" size={12} /></button>
                    <button className="btn btn-ghost btn-icon" title="Reject"><I name="x" size={12} /></button>
                    <button className="btn btn-ghost btn-icon" title="Save to library"><I name="bookmark" size={12} /></button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Empty / loading state preview */}
          <div className="mt-6">
            <Eyebrow>States · for design reference</Eyebrow>
            <div className="row gap-3 mt-3" style={{ flexWrap: "wrap" }}>
              <Card style={{ width: 220, textAlign: "center" }}>
                <div style={{ aspectRatio: "16/10", borderRadius: 8, background: "oklch(0.13 0.012 265)", display: "grid", placeItems: "center", color: "var(--ink-4)" }}>
                  <I name="spinner" size={20} className="mono" />
                </div>
                <div className="dim fz-11 mt-2">Generating 4/6…</div>
              </Card>
              <Card style={{ width: 220, textAlign: "center" }}>
                <div style={{ aspectRatio: "16/10", borderRadius: 8, background: "oklch(0.13 0.012 265)", border: "1px dashed var(--hair-3)", display: "grid", placeItems: "center", color: "var(--ink-3)", fontSize: 11 }}>
                  No variations yet — describe what you want.
                </div>
                <div className="dim fz-11 mt-2">Empty state</div>
              </Card>
              <Card style={{ width: 220, textAlign: "center" }}>
                <div style={{ aspectRatio: "16/10", borderRadius: 8, background: "oklch(0.16 0.04 25 / 0.4)", border: "1px solid oklch(0.66 0.20 25 / 0.4)", display: "grid", placeItems: "center", color: "var(--crit)", fontSize: 11 }}>
                  Provider rate-limited — failover to Imagen
                </div>
                <div className="dim fz-11 mt-2">Error / failover</div>
              </Card>
            </div>
          </div>
        </div>
      </Card>

      {/* Right: Shay review + metadata */}
      <Card style={{ padding: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div className="p-3" style={{ borderBottom: "1px solid var(--hair)" }}>
          <div className="row gap-2"><Avatar kind="shay" initials="S" /><div><div className="fw-500 fz-13">Shay's review</div><div className="dim fz-11">checking against site voice + slot brief</div></div></div>
        </div>
        <div className="p-3" style={{ flex: 1, overflow: "auto" }}>
          <Card style={{ background: "oklch(0.13 0.012 265)" }}>
            <Eyebrow>Pick of the litter</Eyebrow>
            <MediaTile seed={14} ratio="16/10" style={{ marginTop: 8 }} />
            <div className="muted fz-12 mt-3">v2 lands the warmth without losing the signage detail. v4 is gorgeous but too dark for above-the-fold; the headline won't read.</div>
            <div className="row gap-2 mt-3"><Btn icon="check" kind="primary">Approve v2</Btn><Btn>Save all to library</Btn></div>
          </Card>

          <div className="mt-4">
            <Eyebrow>Metadata</Eyebrow>
            <div className="col gap-2 mt-2 fz-11">
              {[
                ["prompt", "Sunday market stall, amber dusk…"],
                ["provider", "Firefly"],
                ["model", "image-3"],
                ["seed", "amber-dusk-04"],
                ["safety", "passed"],
                ["cost", "$0.36 (6 × $0.06)"],
                ["latency", "27.4s"],
                ["license", "commercial-ok"],
              ].map(([k, v]) => (
                <div key={k} className="row between" style={{ padding: "6px 10px", borderRadius: 6, border: "1px solid var(--hair)" }}>
                  <span className="mono dim">{k}</span><span className="mono" style={{ color: "var(--ink-2)" }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="p-3" style={{ borderTop: "1px solid var(--hair)" }}>
          <Btn icon="layers" style={{ width: "100%", justifyContent: "center" }}>Send to Media Library</Btn>
        </div>
      </Card>
    </div>
  );
}

window.ScreenMediaStudio = ScreenMediaStudio;
