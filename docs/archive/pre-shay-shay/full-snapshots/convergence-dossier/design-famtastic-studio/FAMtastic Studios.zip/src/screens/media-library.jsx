/* Media Library — asset registry */

function ScreenMediaLibrary() {
  const tiles = Array.from({ length: 24 }, (_, i) => {
    const slot = i % 6 === 0 ? "missing" : i % 5 === 0 ? "review" : "approved";
    const usage = i % 4 === 0 ? "unused" : i % 3 === 0 ? "in 1 site" : "in 2 sites";
    return { seed: 100 + i, slot, usage };
  });

  return (
    <div className="fade-up">
      <SectionHeader
        eyebrow="Media Library · 184 assets · 12 missing"
        title="Where every pixel earns a name."
        sub="Generated, uploaded, and approved assets — tagged with provenance, prompt, cost, and where they live."
        right={
          <>
            <Btn icon="upload">Upload</Btn>
            <Btn icon="zap" kind="primary">Generate new</Btn>
          </>
        }
      />

      {/* Filters */}
      <Card style={{ marginBottom: 14, padding: 12 }}>
        <div className="row gap-2" style={{ flexWrap: "wrap" }}>
          <input className="input" style={{ maxWidth: 260 }} placeholder="Search by prompt, slot, site…" />
          <div className="seg">{["All","Approved","Review","Missing","Deferred"].map((f, i) => <button key={f} className={i === 0 ? "on" : ""}>{f}</button>)}</div>
          <div className="seg">{["All sources","Firefly","Imagen","Mid-J","Uploaded"].map((f, i) => <button key={f} className={i === 0 ? "on" : ""}>{f}</button>)}</div>
          <div className="seg">{["All sites","Auntie Gale","Hi-Tide","Lawn Care","Groove"].map((f, i) => <button key={f} className={i === 0 ? "on" : ""}>{f}</button>)}</div>
          <div style={{ marginLeft: "auto" }} className="row gap-2"><Btn kind="ghost" icon="filter">More</Btn></div>
        </div>
      </Card>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 14 }}>
        {/* Grid */}
        <Card style={{ padding: 12 }}>
          <div className="between mb-3">
            <div className="h-section">All assets</div>
            <span className="dim fz-11 mono">showing 24 / 184</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 10 }}>
            {tiles.map((t, i) => (
              <div key={i} style={{ position: "relative" }}>
                <MediaTile seed={t.seed} ratio="1/1" />
                <div style={{ position: "absolute", left: 6, top: 6 }}>
                  {t.slot === "approved" ? <Dot tone="good" /> : t.slot === "review" ? <Dot tone="warn" /> : <Dot tone="crit" />}
                </div>
                <div className="dim fz-11 mt-2" style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.usage}</div>
              </div>
            ))}
          </div>

          <div className="mt-4">
            <div className="row gap-3 fz-11 dim">
              <span><Dot tone="good" /> approved</span>
              <span><Dot tone="warn" /> needs review</span>
              <span><Dot tone="crit" /> missing</span>
            </div>
          </div>

          {/* Missing / deferred row */}
          <div className="mt-6">
            <Eyebrow>Missing / deferred · 12</Eyebrow>
            <div className="col gap-2 mt-3">
              {[
                { site: "Auntie Gale", slot: "shop-hero", reason: "deferred until product list final", chip: "warn" },
                { site: "Auntie Gale", slot: "seasonal-bundle", reason: "no product photo yet", chip: "warn" },
                { site: "Hi-Tide Harry", slot: "team-portrait", reason: "awaiting upload from Fritz", chip: "" },
                { site: "Lawn Care", slot: "neighborhood-map", reason: "to generate from new template", chip: "" },
              ].map((m, i) => (
                <div key={i} className="row between" style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid var(--hair)" }}>
                  <div className="row gap-2 grow">
                    <Tag>{m.slot}</Tag>
                    <span className="fz-12 muted">{m.site}</span>
                    <span className="dim fz-11" style={{ marginLeft: 8 }}>{m.reason}</span>
                  </div>
                  <div className="row gap-2">
                    <Btn kind="ghost" icon="upload">Upload</Btn>
                    <Btn icon="zap">Generate</Btn>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Detail */}
        <Card>
          <div className="between mb-3"><div className="h-section">Asset detail</div><Tag>amber-dusk-04</Tag></div>
          <MediaTile seed={14} ratio="1/1" />
          <div className="mt-3">
            <div className="fw-500 fz-13">Sunday market stall · amber dusk</div>
            <div className="muted fz-11 mt-2">Generated · approved by Shay · used in 1 slot</div>
          </div>

          <div className="mt-4">
            <Eyebrow>Provenance</Eyebrow>
            <div className="col gap-2 mt-2 fz-11">
              {[
                ["source", "Firefly · image-3"],
                ["prompt", "Sunday market stall…"],
                ["seed", "amber-dusk-04"],
                ["cost", "$0.06"],
                ["license", "commercial-ok"],
                ["created", "May 12 · 07:14"],
              ].map(([k, v]) => (
                <div key={k} className="row between"><span className="mono dim">{k}</span><span className="mono" style={{ color: "var(--ink-2)" }}>{v}</span></div>
              ))}
            </div>
          </div>

          <div className="mt-4">
            <Eyebrow>Placement</Eyebrow>
            <div className="col gap-2 mt-2">
              <div className="row between" style={{ padding: "6px 8px", borderRadius: 6, border: "1px solid var(--hair)" }}>
                <div className="row gap-2"><I name="sites" size={12} /><span className="fz-12">Auntie Gale</span><Tag>shop-hero</Tag></div>
                <Btn kind="ghost" icon="arrowUpRight" />
              </div>
              <div className="slot fz-11">+ Use in another slot</div>
            </div>
          </div>

          <div className="mt-4">
            <Eyebrow>Compatible components</Eyebrow>
            <div className="row gap-2 mt-2" style={{ flexWrap: "wrap" }}>
              <Chip>fam-hero-layered</Chip><Chip>section-intro · two-col</Chip><Chip>cta-band · shop</Chip>
            </div>
          </div>

          <div className="row gap-2 mt-4">
            <Btn>Variants</Btn>
            <Btn kind="ghost" icon="copy">Duplicate</Btn>
            <Btn kind="ghost" icon="trash" />
          </div>
        </Card>
      </div>
    </div>
  );
}

window.ScreenMediaLibrary = ScreenMediaLibrary;
